﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmBatchesMaster : myForm
    {
        string sql = "select * from batches";
        myFunctions myFun = new myFunctions();
        MySqlConnection con;
        MySqlDataAdapter adapter;
        DataTable table;
        public frmBatchesMaster()
        {
            InitializeComponent();
        }
        //this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
        // for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com

        private void btnNewBatch_Click(object sender, EventArgs e)
        {
            frmAddBatch f = new frmAddBatch(0);
            f.ShowDialog();
            refreshGrid(sql);
        }
        private void refreshGrid(string query)
        {
            try
            {
                con = new MySqlConnection(myFun.getstring());

                adapter = new MySqlDataAdapter(query, con);
                //cmdBuilder = new MySqlCommandBuilder(adapter);
                table = new DataTable();
                table.Clear();
                adapter.Fill(table);
                //if (table.Rows.Count > 0)
                dgBatches.DataSource = table;
                dgBatches.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgBatches.Columns[0].Width = 100;
                dgBatches.Columns[1].Width = 250;
                dgBatches.Columns[2].Width = 150;
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //code by nikhil freelancer
        // for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com

        private void frmBatchesMaster_Load(object sender, EventArgs e)
        {
            sql = "select * from batches";
            refreshGrid(sql);
        }

        private void dgBatches_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            editBatch();
        }

        private void dgBatches_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                editBatch();
            }
        }

        private void editBatch()
        {
            int id = int.Parse(dgBatches.SelectedCells[0].Value.ToString());
            frmAddBatch f = new frmAddBatch(id);
            f.ShowDialog();
            refreshGrid(sql);
        }
    }
}
