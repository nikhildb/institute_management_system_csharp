﻿namespace IMS
{
    partial class frmDepositFee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myLabel1 = new IMS.myLabel();
            this.cmbStudents = new IMS.myComboBox();
            this.myLabel2 = new IMS.myLabel();
            this.txtCourse = new IMS.myTextBox();
            this.myLabel3 = new IMS.myLabel();
            this.txtTotalFees = new IMS.myTextBox();
            this.myLabel4 = new IMS.myLabel();
            this.txtRecievedFee = new IMS.myTextBox();
            this.myLabel5 = new IMS.myLabel();
            this.txtDepositNow = new IMS.myTextBox();
            this.dtDate = new System.Windows.Forms.DateTimePicker();
            this.myLabel6 = new IMS.myLabel();
            this.myPrimaryBtn1 = new IMS.myPrimaryBtn();
            this.btnPrint = new IMS.myPrimaryBtn();
            this.SuspendLayout();
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel1.ForeColor = System.Drawing.Color.White;
            this.myLabel1.Location = new System.Drawing.Point(47, 56);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(163, 23);
            this.myLabel1.TabIndex = 0;
            this.myLabel1.Text = "Select Student :";
            // 
            // cmbStudents
            // 
            this.cmbStudents.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStudents.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.cmbStudents.FormattingEnabled = true;
            this.cmbStudents.Location = new System.Drawing.Point(238, 48);
            this.cmbStudents.Name = "cmbStudents";
            this.cmbStudents.Size = new System.Drawing.Size(402, 31);
            this.cmbStudents.TabIndex = 1;
            this.cmbStudents.SelectedIndexChanged += new System.EventHandler(this.cmbStudents_SelectedIndexChanged);
            // 
            // myLabel2
            // 
            this.myLabel2.AutoSize = true;
            this.myLabel2.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel2.ForeColor = System.Drawing.Color.White;
            this.myLabel2.Location = new System.Drawing.Point(50, 107);
            this.myLabel2.Name = "myLabel2";
            this.myLabel2.Size = new System.Drawing.Size(89, 23);
            this.myLabel2.TabIndex = 2;
            this.myLabel2.Text = "Course :";
            // 
            // txtCourse
            // 
            this.txtCourse.Enabled = false;
            this.txtCourse.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtCourse.Location = new System.Drawing.Point(237, 100);
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(250, 32);
            this.txtCourse.TabIndex = 3;
            // 
            // myLabel3
            // 
            this.myLabel3.AutoSize = true;
            this.myLabel3.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel3.ForeColor = System.Drawing.Color.White;
            this.myLabel3.Location = new System.Drawing.Point(50, 155);
            this.myLabel3.Name = "myLabel3";
            this.myLabel3.Size = new System.Drawing.Size(118, 23);
            this.myLabel3.TabIndex = 2;
            this.myLabel3.Text = "Total Fees :";
            // 
            // txtTotalFees
            // 
            this.txtTotalFees.Enabled = false;
            this.txtTotalFees.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtTotalFees.Location = new System.Drawing.Point(237, 148);
            this.txtTotalFees.Name = "txtTotalFees";
            this.txtTotalFees.Size = new System.Drawing.Size(250, 32);
            this.txtTotalFees.TabIndex = 3;
            // 
            // myLabel4
            // 
            this.myLabel4.AutoSize = true;
            this.myLabel4.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel4.ForeColor = System.Drawing.Color.White;
            this.myLabel4.Location = new System.Drawing.Point(51, 202);
            this.myLabel4.Name = "myLabel4";
            this.myLabel4.Size = new System.Drawing.Size(157, 23);
            this.myLabel4.TabIndex = 2;
            this.myLabel4.Text = "Received Fee :";
            // 
            // txtRecievedFee
            // 
            this.txtRecievedFee.Enabled = false;
            this.txtRecievedFee.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtRecievedFee.Location = new System.Drawing.Point(238, 195);
            this.txtRecievedFee.Name = "txtRecievedFee";
            this.txtRecievedFee.Size = new System.Drawing.Size(250, 32);
            this.txtRecievedFee.TabIndex = 3;
            // 
            // myLabel5
            // 
            this.myLabel5.AutoSize = true;
            this.myLabel5.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel5.ForeColor = System.Drawing.Color.White;
            this.myLabel5.Location = new System.Drawing.Point(51, 253);
            this.myLabel5.Name = "myLabel5";
            this.myLabel5.Size = new System.Drawing.Size(178, 23);
            this.myLabel5.TabIndex = 2;
            this.myLabel5.Text = "Deposit Amount :";
            // 
            // txtDepositNow
            // 
            this.txtDepositNow.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtDepositNow.Location = new System.Drawing.Point(238, 246);
            this.txtDepositNow.Name = "txtDepositNow";
            this.txtDepositNow.Size = new System.Drawing.Size(250, 32);
            this.txtDepositNow.TabIndex = 3;
            // 
            // dtDate
            // 
            this.dtDate.CustomFormat = "dd/MM/yyyy";
            this.dtDate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDate.Location = new System.Drawing.Point(238, 293);
            this.dtDate.Name = "dtDate";
            this.dtDate.Size = new System.Drawing.Size(160, 27);
            this.dtDate.TabIndex = 7;
            // 
            // myLabel6
            // 
            this.myLabel6.AutoSize = true;
            this.myLabel6.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel6.ForeColor = System.Drawing.Color.White;
            this.myLabel6.Location = new System.Drawing.Point(51, 297);
            this.myLabel6.Name = "myLabel6";
            this.myLabel6.Size = new System.Drawing.Size(70, 23);
            this.myLabel6.TabIndex = 2;
            this.myLabel6.Text = "Date :";
            // 
            // myPrimaryBtn1
            // 
            this.myPrimaryBtn1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.myPrimaryBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myPrimaryBtn1.FlatAppearance.BorderSize = 0;
            this.myPrimaryBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.myPrimaryBtn1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myPrimaryBtn1.ForeColor = System.Drawing.Color.White;
            this.myPrimaryBtn1.Location = new System.Drawing.Point(238, 354);
            this.myPrimaryBtn1.Name = "myPrimaryBtn1";
            this.myPrimaryBtn1.Size = new System.Drawing.Size(136, 39);
            this.myPrimaryBtn1.TabIndex = 8;
            this.myPrimaryBtn1.Text = "Save";
            this.myPrimaryBtn1.UseVisualStyleBackColor = false;
            this.myPrimaryBtn1.Click += new System.EventHandler(this.myPrimaryBtn1_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrint.FlatAppearance.BorderSize = 0;
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrint.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.btnPrint.Location = new System.Drawing.Point(403, 354);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(136, 39);
            this.btnPrint.TabIndex = 8;
            this.btnPrint.Text = "Print Invoice";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // frmDepositFee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(653, 441);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.myPrimaryBtn1);
            this.Controls.Add(this.dtDate);
            this.Controls.Add(this.txtDepositNow);
            this.Controls.Add(this.myLabel6);
            this.Controls.Add(this.myLabel5);
            this.Controls.Add(this.txtRecievedFee);
            this.Controls.Add(this.myLabel4);
            this.Controls.Add(this.txtTotalFees);
            this.Controls.Add(this.myLabel3);
            this.Controls.Add(this.txtCourse);
            this.Controls.Add(this.myLabel2);
            this.Controls.Add(this.cmbStudents);
            this.Controls.Add(this.myLabel1);
            this.Name = "frmDepositFee";
            this.Text = "frmDepositFee";
            this.Load += new System.EventHandler(this.frmDepositFee_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private myLabel myLabel1;
        private myComboBox cmbStudents;
        private myLabel myLabel2;
        private myTextBox txtCourse;
        private myLabel myLabel3;
        private myTextBox txtTotalFees;
        private myLabel myLabel4;
        private myTextBox txtRecievedFee;
        private myLabel myLabel5;
        private myTextBox txtDepositNow;
        private System.Windows.Forms.DateTimePicker dtDate;
        private myLabel myLabel6;
        private myPrimaryBtn myPrimaryBtn1;
        private myPrimaryBtn btnPrint;
    }
}