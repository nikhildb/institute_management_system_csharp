﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace IMS
{
    public partial class frmSMS : myForm
    {
        String sql;
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;
        myFunctions myFun=new myFunctions();
        String numbers;
        public frmSMS()
        {
            InitializeComponent();
        }
//this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
// for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com
        private void btnSendSMS_Click(object sender, EventArgs e)
        {
            try
            {
                con = new MySqlConnection(myFun.getstring());
                con.Open();
                sql = "select mobile from students where course='" + cmbCourse.Text + "' and batch='" + cmbBatch.Text + "'";
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    numbers += reader["mobile"] + ",";
                }
                numbers = numbers.Substring(0, numbers.Length - 1);
                string result;
                using (var wb = new WebClient())
                {
                    byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , ""},
                {"numbers" , "9423979339"},
                {"message" , txtMsg.Text},
                {"sender" , ""}
                });
                    result = System.Text.Encoding.UTF8.GetString(response);
                }
                //MessageBox.Show(numbers.ToString());
                MessageBox.Show(result);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex.Message);
            }
            

        }

        private void frmSMS_Load(object sender, EventArgs e)
        {
            LoadCombo();
        }
        private void LoadCombo()
        {
            //load cource combo
            sql = "select c_name from courses";
            try
            {
                con = new MySqlConnection(myFun.getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cmbCourse.Items.Add(reader[0].ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();

            }
            //load batch combo
            sql = "select b_name from batches";
            try
            {
                con = new MySqlConnection(myFun.getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cmbBatch.Items.Add(reader[0].ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();

            }
        }
    }
}
