﻿namespace IMS
{
    partial class frmSMS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myLabel1 = new IMS.myLabel();
            this.myLabel2 = new IMS.myLabel();
            this.myLabel3 = new IMS.myLabel();
            this.cmbCourse = new IMS.myComboBox();
            this.cmbBatch = new IMS.myComboBox();
            this.txtMsg = new IMS.myTextBox();
            this.btnSendSMS = new IMS.myPrimaryBtn();
            this.SuspendLayout();
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel1.ForeColor = System.Drawing.Color.White;
            this.myLabel1.Location = new System.Drawing.Point(62, 34);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(156, 23);
            this.myLabel1.TabIndex = 0;
            this.myLabel1.Text = "Select Course :";
            // 
            // myLabel2
            // 
            this.myLabel2.AutoSize = true;
            this.myLabel2.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel2.ForeColor = System.Drawing.Color.White;
            this.myLabel2.Location = new System.Drawing.Point(66, 100);
            this.myLabel2.Name = "myLabel2";
            this.myLabel2.Size = new System.Drawing.Size(145, 23);
            this.myLabel2.TabIndex = 1;
            this.myLabel2.Text = "Select Batch :";
            // 
            // myLabel3
            // 
            this.myLabel3.AutoSize = true;
            this.myLabel3.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel3.ForeColor = System.Drawing.Color.White;
            this.myLabel3.Location = new System.Drawing.Point(66, 157);
            this.myLabel3.Name = "myLabel3";
            this.myLabel3.Size = new System.Drawing.Size(162, 23);
            this.myLabel3.TabIndex = 2;
            this.myLabel3.Text = "Enter Message :";
            // 
            // cmbCourse
            // 
            this.cmbCourse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCourse.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.cmbCourse.FormattingEnabled = true;
            this.cmbCourse.Location = new System.Drawing.Point(261, 34);
            this.cmbCourse.Name = "cmbCourse";
            this.cmbCourse.Size = new System.Drawing.Size(302, 31);
            this.cmbCourse.TabIndex = 3;
            // 
            // cmbBatch
            // 
            this.cmbBatch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBatch.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.cmbBatch.FormattingEnabled = true;
            this.cmbBatch.Location = new System.Drawing.Point(261, 100);
            this.cmbBatch.Name = "cmbBatch";
            this.cmbBatch.Size = new System.Drawing.Size(302, 31);
            this.cmbBatch.TabIndex = 4;
            // 
            // txtMsg
            // 
            this.txtMsg.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtMsg.Location = new System.Drawing.Point(261, 157);
            this.txtMsg.Multiline = true;
            this.txtMsg.Name = "txtMsg";
            this.txtMsg.Size = new System.Drawing.Size(302, 150);
            this.txtMsg.TabIndex = 5;
            // 
            // btnSendSMS
            // 
            this.btnSendSMS.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnSendSMS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSendSMS.FlatAppearance.BorderSize = 0;
            this.btnSendSMS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSendSMS.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnSendSMS.ForeColor = System.Drawing.Color.White;
            this.btnSendSMS.Location = new System.Drawing.Point(261, 334);
            this.btnSendSMS.Name = "btnSendSMS";
            this.btnSendSMS.Size = new System.Drawing.Size(158, 42);
            this.btnSendSMS.TabIndex = 6;
            this.btnSendSMS.Text = "Send SMS";
            this.btnSendSMS.UseVisualStyleBackColor = false;
            this.btnSendSMS.Click += new System.EventHandler(this.btnSendSMS_Click);
            // 
            // frmSMS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(619, 422);
            this.Controls.Add(this.btnSendSMS);
            this.Controls.Add(this.txtMsg);
            this.Controls.Add(this.cmbBatch);
            this.Controls.Add(this.cmbCourse);
            this.Controls.Add(this.myLabel3);
            this.Controls.Add(this.myLabel2);
            this.Controls.Add(this.myLabel1);
            this.Name = "frmSMS";
            this.Text = "SMS";
            this.Load += new System.EventHandler(this.frmSMS_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private myLabel myLabel1;
        private myLabel myLabel2;
        private myLabel myLabel3;
        private myComboBox cmbCourse;
        private myComboBox cmbBatch;
        private myTextBox txtMsg;
        private myPrimaryBtn btnSendSMS;
    }
}