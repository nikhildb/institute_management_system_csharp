﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmReportViewer : myForm
    {
        public frmReportViewer(string report, int fid)
        {
            InitializeComponent();
            if (report == "student")
            {
                crystalReportViewer1.ReportSource=new rptStudents();
            }
            else if (report == "expense")
            {
                crystalReportViewer1.ReportSource = new rptExpenses();
            }
            else if (report == "fees")
            {
                crystalReportViewer1.ReportSource = new rptFees();
            }
            else if (report == "invoice")
            {
                if (fid != 0)
                {
                    rptFeeInvoice fi = new rptFeeInvoice();
                    fi.SetParameterValue(0, fid);
                    crystalReportViewer1.ReportSource =fi;
                }
            }
        }

        private void frmReportViewer_Load(object sender, EventArgs e)
        {

        }
    }
}
