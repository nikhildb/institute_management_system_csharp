﻿namespace IMS
{
    partial class frmDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashboard));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.manageCoursesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageBatchesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripEnquirybtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSMSButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.myLabel10 = new IMS.myLabel();
            this.myLabel9 = new IMS.myLabel();
            this.myLabel8 = new IMS.myLabel();
            this.myLabel2 = new IMS.myLabel();
            this.myLabel1 = new IMS.myLabel();
            this.myLabel7 = new IMS.myLabel();
            this.dgvFeesRemainder = new IMS.myGridView();
            this.dgvEnquiryFolloups = new IMS.myGridView();
            this.btnTotalEnq = new IMS.myPrimaryBtn();
            this.btnTotalBatch = new IMS.myPrimaryBtn();
            this.btnTotalCourses = new IMS.myPrimaryBtn();
            this.btnTotalStuds = new IMS.myPrimaryBtn();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeesRemainder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEnquiryFolloups)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 82);
            this.panel1.TabIndex = 1;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButton1,
            this.toolStripEnquirybtn,
            this.toolStripButton1,
            this.toolStripSMSButton,
            this.toolStripButton2,
            this.toolStripButton4,
            this.toolStripButton3,
            this.toolStripButton5});
            this.toolStrip1.Location = new System.Drawing.Point(0, 82);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(778, 29);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manageCoursesToolStripMenuItem,
            this.manageBatchesToolStripMenuItem});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(208, 26);
            this.toolStripSplitButton1.Text = "Courses && Batches";
            // 
            // manageCoursesToolStripMenuItem
            // 
            this.manageCoursesToolStripMenuItem.Name = "manageCoursesToolStripMenuItem";
            this.manageCoursesToolStripMenuItem.Size = new System.Drawing.Size(239, 26);
            this.manageCoursesToolStripMenuItem.Text = "Manage Courses";
            this.manageCoursesToolStripMenuItem.Click += new System.EventHandler(this.manageCoursesToolStripMenuItem_Click);
            // 
            // manageBatchesToolStripMenuItem
            // 
            this.manageBatchesToolStripMenuItem.Name = "manageBatchesToolStripMenuItem";
            this.manageBatchesToolStripMenuItem.Size = new System.Drawing.Size(239, 26);
            this.manageBatchesToolStripMenuItem.Text = "Manage Batches";
            this.manageBatchesToolStripMenuItem.Click += new System.EventHandler(this.manageBatchesToolStripMenuItem_Click);
            // 
            // toolStripEnquirybtn
            // 
            this.toolStripEnquirybtn.Image = ((System.Drawing.Image)(resources.GetObject("toolStripEnquirybtn.Image")));
            this.toolStripEnquirybtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripEnquirybtn.Name = "toolStripEnquirybtn";
            this.toolStripEnquirybtn.Size = new System.Drawing.Size(97, 26);
            this.toolStripEnquirybtn.Text = "Enquiry";
            this.toolStripEnquirybtn.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(109, 26);
            this.toolStripButton1.Text = "Students";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click_1);
            // 
            // toolStripSMSButton
            // 
            this.toolStripSMSButton.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSMSButton.Image")));
            this.toolStripSMSButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSMSButton.Name = "toolStripSMSButton";
            this.toolStripSMSButton.Size = new System.Drawing.Size(65, 26);
            this.toolStripSMSButton.Text = "SMS";
            this.toolStripSMSButton.Click += new System.EventHandler(this.toolStripSMSButton_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(63, 26);
            this.toolStripButton2.Text = "Fee";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(112, 26);
            this.toolStripButton4.Text = "Expenses";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(99, 26);
            this.toolStripButton3.Text = "Reports";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(89, 26);
            this.toolStripButton5.Text = "About";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Yellow;
            this.linkLabel1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(418, 676);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(297, 19);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Click here to check my previous work";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // myLabel10
            // 
            this.myLabel10.AutoSize = true;
            this.myLabel10.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel10.ForeColor = System.Drawing.Color.Black;
            this.myLabel10.Location = new System.Drawing.Point(554, 237);
            this.myLabel10.Name = "myLabel10";
            this.myLabel10.Size = new System.Drawing.Size(145, 23);
            this.myLabel10.TabIndex = 5;
            this.myLabel10.Text = "Total Enquiries";
            // 
            // myLabel9
            // 
            this.myLabel9.AutoSize = true;
            this.myLabel9.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel9.ForeColor = System.Drawing.Color.Black;
            this.myLabel9.Location = new System.Drawing.Point(385, 236);
            this.myLabel9.Name = "myLabel9";
            this.myLabel9.Size = new System.Drawing.Size(141, 23);
            this.myLabel9.TabIndex = 5;
            this.myLabel9.Text = "Total Batches";
            // 
            // myLabel8
            // 
            this.myLabel8.AutoSize = true;
            this.myLabel8.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel8.ForeColor = System.Drawing.Color.Black;
            this.myLabel8.Location = new System.Drawing.Point(222, 236);
            this.myLabel8.Name = "myLabel8";
            this.myLabel8.Size = new System.Drawing.Size(139, 23);
            this.myLabel8.TabIndex = 5;
            this.myLabel8.Text = "Total Courses";
            // 
            // myLabel2
            // 
            this.myLabel2.AutoSize = true;
            this.myLabel2.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel2.ForeColor = System.Drawing.Color.Black;
            this.myLabel2.Location = new System.Drawing.Point(12, 472);
            this.myLabel2.Name = "myLabel2";
            this.myLabel2.Size = new System.Drawing.Size(158, 23);
            this.myLabel2.TabIndex = 5;
            this.myLabel2.Text = "Fee Remainder";
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel1.ForeColor = System.Drawing.Color.Black;
            this.myLabel1.Location = new System.Drawing.Point(12, 284);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(231, 23);
            this.myLabel1.TabIndex = 5;
            this.myLabel1.Text = "Today Enquiry Folloups";
            // 
            // myLabel7
            // 
            this.myLabel7.AutoSize = true;
            this.myLabel7.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel7.ForeColor = System.Drawing.Color.Black;
            this.myLabel7.Location = new System.Drawing.Point(36, 237);
            this.myLabel7.Name = "myLabel7";
            this.myLabel7.Size = new System.Drawing.Size(146, 23);
            this.myLabel7.TabIndex = 5;
            this.myLabel7.Text = "Total Students";
            // 
            // dgvFeesRemainder
            // 
            this.dgvFeesRemainder.AllowUserToAddRows = false;
            this.dgvFeesRemainder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvFeesRemainder.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(2);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvFeesRemainder.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFeesRemainder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFeesRemainder.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFeesRemainder.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvFeesRemainder.EnableHeadersVisualStyles = false;
            this.dgvFeesRemainder.GridColor = System.Drawing.Color.White;
            this.dgvFeesRemainder.Location = new System.Drawing.Point(12, 498);
            this.dgvFeesRemainder.MultiSelect = false;
            this.dgvFeesRemainder.Name = "dgvFeesRemainder";
            this.dgvFeesRemainder.ReadOnly = true;
            this.dgvFeesRemainder.RowHeadersVisible = false;
            this.dgvFeesRemainder.RowTemplate.Height = 50;
            this.dgvFeesRemainder.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFeesRemainder.Size = new System.Drawing.Size(754, 157);
            this.dgvFeesRemainder.TabIndex = 0;
            // 
            // dgvEnquiryFolloups
            // 
            this.dgvEnquiryFolloups.AllowUserToAddRows = false;
            this.dgvEnquiryFolloups.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEnquiryFolloups.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(2);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEnquiryFolloups.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvEnquiryFolloups.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEnquiryFolloups.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvEnquiryFolloups.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvEnquiryFolloups.EnableHeadersVisualStyles = false;
            this.dgvEnquiryFolloups.GridColor = System.Drawing.Color.White;
            this.dgvEnquiryFolloups.Location = new System.Drawing.Point(12, 310);
            this.dgvEnquiryFolloups.MultiSelect = false;
            this.dgvEnquiryFolloups.Name = "dgvEnquiryFolloups";
            this.dgvEnquiryFolloups.ReadOnly = true;
            this.dgvEnquiryFolloups.RowHeadersVisible = false;
            this.dgvEnquiryFolloups.RowTemplate.Height = 50;
            this.dgvEnquiryFolloups.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEnquiryFolloups.Size = new System.Drawing.Size(754, 157);
            this.dgvEnquiryFolloups.TabIndex = 0;
            // 
            // btnTotalEnq
            // 
            this.btnTotalEnq.BackColor = System.Drawing.Color.Purple;
            this.btnTotalEnq.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTotalEnq.FlatAppearance.BorderSize = 0;
            this.btnTotalEnq.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotalEnq.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalEnq.ForeColor = System.Drawing.Color.White;
            this.btnTotalEnq.Location = new System.Drawing.Point(558, 137);
            this.btnTotalEnq.Name = "btnTotalEnq";
            this.btnTotalEnq.Size = new System.Drawing.Size(100, 96);
            this.btnTotalEnq.TabIndex = 4;
            this.btnTotalEnq.Text = "0";
            this.btnTotalEnq.UseVisualStyleBackColor = false;
            this.btnTotalEnq.Click += new System.EventHandler(this.btnEnquiry_Click);
            // 
            // btnTotalBatch
            // 
            this.btnTotalBatch.BackColor = System.Drawing.Color.Maroon;
            this.btnTotalBatch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTotalBatch.FlatAppearance.BorderSize = 0;
            this.btnTotalBatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotalBatch.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalBatch.ForeColor = System.Drawing.Color.White;
            this.btnTotalBatch.Location = new System.Drawing.Point(389, 137);
            this.btnTotalBatch.Name = "btnTotalBatch";
            this.btnTotalBatch.Size = new System.Drawing.Size(100, 96);
            this.btnTotalBatch.TabIndex = 4;
            this.btnTotalBatch.Text = "0";
            this.btnTotalBatch.UseVisualStyleBackColor = false;
            this.btnTotalBatch.Click += new System.EventHandler(this.btnTotalBatches_Click);
            // 
            // btnTotalCourses
            // 
            this.btnTotalCourses.BackColor = System.Drawing.Color.Green;
            this.btnTotalCourses.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTotalCourses.FlatAppearance.BorderSize = 0;
            this.btnTotalCourses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotalCourses.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalCourses.ForeColor = System.Drawing.Color.White;
            this.btnTotalCourses.Location = new System.Drawing.Point(226, 137);
            this.btnTotalCourses.Name = "btnTotalCourses";
            this.btnTotalCourses.Size = new System.Drawing.Size(100, 96);
            this.btnTotalCourses.TabIndex = 4;
            this.btnTotalCourses.Text = "0";
            this.btnTotalCourses.UseVisualStyleBackColor = false;
            this.btnTotalCourses.Click += new System.EventHandler(this.btnTotalCources_Click);
            // 
            // btnTotalStuds
            // 
            this.btnTotalStuds.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnTotalStuds.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTotalStuds.FlatAppearance.BorderSize = 0;
            this.btnTotalStuds.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotalStuds.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalStuds.ForeColor = System.Drawing.Color.White;
            this.btnTotalStuds.Location = new System.Drawing.Point(39, 137);
            this.btnTotalStuds.Name = "btnTotalStuds";
            this.btnTotalStuds.Size = new System.Drawing.Size(100, 96);
            this.btnTotalStuds.TabIndex = 4;
            this.btnTotalStuds.Text = "0";
            this.btnTotalStuds.UseVisualStyleBackColor = false;
            this.btnTotalStuds.Click += new System.EventHandler(this.btnTotalStudents_Click);
            // 
            // frmDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(778, 704);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.myLabel10);
            this.Controls.Add(this.myLabel9);
            this.Controls.Add(this.myLabel8);
            this.Controls.Add(this.myLabel2);
            this.Controls.Add(this.myLabel1);
            this.Controls.Add(this.myLabel7);
            this.Controls.Add(this.dgvFeesRemainder);
            this.Controls.Add(this.dgvEnquiryFolloups);
            this.Controls.Add(this.btnTotalEnq);
            this.Controls.Add(this.btnTotalBatch);
            this.Controls.Add(this.btnTotalCourses);
            this.Controls.Add(this.btnTotalStuds);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmDashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDashboard_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmDashboard_FormClosed);
            this.Load += new System.EventHandler(this.frmDashboard_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeesRemainder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEnquiryFolloups)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        
        private System.Windows.Forms.Panel panel1;
        
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem manageCoursesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageBatchesToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripEnquirybtn;
       
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripSMSButton;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
       
        private myPrimaryBtn btnTotalStuds;
        private myPrimaryBtn btnTotalCourses;
        private myPrimaryBtn btnTotalBatch;
        private myPrimaryBtn btnTotalEnq;
        private myGridView dgvEnquiryFolloups;
        private myLabel myLabel7;
        private myLabel myLabel8;
        private myLabel myLabel9;
        private myLabel myLabel10;
        private myGridView dgvFeesRemainder;
        private myLabel myLabel1;
        private myLabel myLabel2;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}