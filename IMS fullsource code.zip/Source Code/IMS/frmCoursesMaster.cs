﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmCoursesMaster : myForm
    {
        string sql = "select * from courses";
        myFunctions myFun = new myFunctions();
        MySqlConnection con;
        MySqlDataAdapter adapter;
        DataTable table;
        public frmCoursesMaster()
        {
            InitializeComponent();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            sql = "select * from courses where c_name like '%" + txtSearch.Text + "%'";
            refreshGrid(sql);
        }
        private void refreshGrid(string query)
        {
            try
            {
                con = new MySqlConnection(myFun.getstring());
                
                adapter = new MySqlDataAdapter(query, con);
                //cmdBuilder = new MySqlCommandBuilder(adapter);
                table = new DataTable();
                table.Clear();
                adapter.Fill(table);
                //if (table.Rows.Count > 0)
                dgCourses.DataSource = table;
                dgCourses.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgCourses.Columns[0].Width = 100;
                dgCourses.Columns[1].Width = 250;
                dgCourses.Columns[2].Width = 300;
                dgCourses.Columns[3].Width = 150;
                dgCourses.Columns[4].Width = 150;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void frmCoursesMaster_Load(object sender, EventArgs e)
        {

            refreshGrid(sql);
        }

        private void btnAddCource_Click(object sender, EventArgs e)
        {
            frmAddCourse f = new frmAddCourse(0);
            f.ShowDialog();
            refreshGrid(sql);
        }
        //this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
        // for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com

        private void dgCourses_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            editCourse();
        }
        private void editCourse()
        {
            int id = int.Parse(dgCourses.SelectedCells[0].Value.ToString());
            frmAddCourse f = new frmAddCourse(id);
            f.ShowDialog();
            refreshGrid(sql);
        }

        private void dgCourses_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                editCourse();
            }
        }
    }
}
