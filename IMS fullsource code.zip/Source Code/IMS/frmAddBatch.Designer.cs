﻿namespace IMS
{
    partial class frmAddBatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myLabel1 = new IMS.myLabel();
            this.myLabel2 = new IMS.myLabel();
            this.txtBatchName = new IMS.myTextBox();
            this.btnAddBatch = new IMS.myPrimaryBtn();
            this.cmbStatus = new IMS.myComboBox();
            this.btnDelete = new IMS.myPrimaryBtn();
            this.SuspendLayout();
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel1.ForeColor = System.Drawing.Color.White;
            this.myLabel1.Location = new System.Drawing.Point(12, 51);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(145, 23);
            this.myLabel1.TabIndex = 0;
            this.myLabel1.Text = "Batch Name :";
            // 
            // myLabel2
            // 
            this.myLabel2.AutoSize = true;
            this.myLabel2.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel2.ForeColor = System.Drawing.Color.White;
            this.myLabel2.Location = new System.Drawing.Point(78, 93);
            this.myLabel2.Name = "myLabel2";
            this.myLabel2.Size = new System.Drawing.Size(79, 23);
            this.myLabel2.TabIndex = 1;
            this.myLabel2.Text = "Status :";
            // 
            // txtBatchName
            // 
            this.txtBatchName.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtBatchName.Location = new System.Drawing.Point(163, 42);
            this.txtBatchName.Name = "txtBatchName";
            this.txtBatchName.Size = new System.Drawing.Size(209, 32);
            this.txtBatchName.TabIndex = 2;
            // 
            // btnAddBatch
            // 
            this.btnAddBatch.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnAddBatch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddBatch.FlatAppearance.BorderSize = 0;
            this.btnAddBatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddBatch.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnAddBatch.ForeColor = System.Drawing.Color.White;
            this.btnAddBatch.Location = new System.Drawing.Point(258, 141);
            this.btnAddBatch.Name = "btnAddBatch";
            this.btnAddBatch.Size = new System.Drawing.Size(114, 35);
            this.btnAddBatch.TabIndex = 4;
            this.btnAddBatch.Text = "Add";
            this.btnAddBatch.UseVisualStyleBackColor = false;
            this.btnAddBatch.Click += new System.EventHandler(this.btnAddBatch_Click);
            // 
            // cmbStatus
            // 
            this.cmbStatus.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Active",
            "InActive"});
            this.cmbStatus.Location = new System.Drawing.Point(164, 93);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(208, 31);
            this.cmbStatus.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.DarkOrange;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(138, 141);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(114, 35);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // frmAddBatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(392, 190);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAddBatch);
            this.Controls.Add(this.txtBatchName);
            this.Controls.Add(this.myLabel2);
            this.Controls.Add(this.myLabel1);
            this.Name = "frmAddBatch";
            this.Text = "Add New Batch";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private myLabel myLabel1;
        private myLabel myLabel2;
        private myTextBox txtBatchName;
        private myPrimaryBtn btnAddBatch;
        private myComboBox cmbStatus;
        private myPrimaryBtn btnDelete;
    }
}