﻿namespace IMS
{
    partial class frmCoursesMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnAddCource = new IMS.myPrimaryBtn();
            this.txtSearch = new IMS.myTextBox();
            this.myLabel1 = new IMS.myLabel();
            this.dgCourses = new IMS.myGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgCourses)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddCource
            // 
            this.btnAddCource.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddCource.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnAddCource.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddCource.FlatAppearance.BorderSize = 0;
            this.btnAddCource.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCource.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnAddCource.ForeColor = System.Drawing.Color.White;
            this.btnAddCource.Location = new System.Drawing.Point(751, 36);
            this.btnAddCource.Name = "btnAddCource";
            this.btnAddCource.Size = new System.Drawing.Size(177, 43);
            this.btnAddCource.TabIndex = 3;
            this.btnAddCource.Text = "Add Course";
            this.btnAddCource.UseVisualStyleBackColor = false;
            this.btnAddCource.Click += new System.EventHandler(this.btnAddCource_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtSearch.Location = new System.Drawing.Point(172, 38);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(288, 32);
            this.txtSearch.TabIndex = 2;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel1.ForeColor = System.Drawing.Color.Black;
            this.myLabel1.Location = new System.Drawing.Point(76, 43);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(89, 23);
            this.myLabel1.TabIndex = 1;
            this.myLabel1.Text = "Search :";
            // 
            // dgCourses
            // 
            this.dgCourses.AllowUserToAddRows = false;
            this.dgCourses.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgCourses.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(2);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgCourses.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCourses.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgCourses.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgCourses.EnableHeadersVisualStyles = false;
            this.dgCourses.GridColor = System.Drawing.Color.White;
            this.dgCourses.Location = new System.Drawing.Point(0, 85);
            this.dgCourses.MultiSelect = false;
            this.dgCourses.Name = "dgCourses";
            this.dgCourses.ReadOnly = true;
            this.dgCourses.RowHeadersVisible = false;
            this.dgCourses.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgCourses.Size = new System.Drawing.Size(935, 363);
            this.dgCourses.TabIndex = 0;
            this.dgCourses.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgCourses_CellDoubleClick);
            this.dgCourses.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgCourses_KeyDown);
            // 
            // frmCoursesMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(934, 450);
            this.Controls.Add(this.dgCourses);
            this.Controls.Add(this.btnAddCource);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.myLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmCoursesMaster";
            this.Text = "Courses Master";
            this.Load += new System.EventHandler(this.frmCoursesMaster_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgCourses)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private myLabel myLabel1;
        private myTextBox txtSearch;
        private myPrimaryBtn btnAddCource;
        private myGridView dgCourses;
    }
}