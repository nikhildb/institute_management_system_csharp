﻿namespace IMS
{
    partial class frmReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFeesReport = new IMS.myPrimaryBtn();
            this.btnStudReport = new IMS.myPrimaryBtn();
            this.btnExpenseReport = new IMS.myPrimaryBtn();
            this.SuspendLayout();
            // 
            // btnFeesReport
            // 
            this.btnFeesReport.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnFeesReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFeesReport.FlatAppearance.BorderSize = 0;
            this.btnFeesReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFeesReport.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnFeesReport.ForeColor = System.Drawing.Color.White;
            this.btnFeesReport.Location = new System.Drawing.Point(207, 147);
            this.btnFeesReport.Name = "btnFeesReport";
            this.btnFeesReport.Size = new System.Drawing.Size(443, 44);
            this.btnFeesReport.TabIndex = 0;
            this.btnFeesReport.Text = "Fee Report";
            this.btnFeesReport.UseVisualStyleBackColor = false;
            this.btnFeesReport.Click += new System.EventHandler(this.myPrimaryBtn1_Click);
            // 
            // btnStudReport
            // 
            this.btnStudReport.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnStudReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStudReport.FlatAppearance.BorderSize = 0;
            this.btnStudReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStudReport.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnStudReport.ForeColor = System.Drawing.Color.White;
            this.btnStudReport.Location = new System.Drawing.Point(207, 207);
            this.btnStudReport.Name = "btnStudReport";
            this.btnStudReport.Size = new System.Drawing.Size(443, 44);
            this.btnStudReport.TabIndex = 0;
            this.btnStudReport.Text = "Student Report";
            this.btnStudReport.UseVisualStyleBackColor = false;
            this.btnStudReport.Click += new System.EventHandler(this.btnStudReport_Click);
            // 
            // btnExpenseReport
            // 
            this.btnExpenseReport.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnExpenseReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpenseReport.FlatAppearance.BorderSize = 0;
            this.btnExpenseReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExpenseReport.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnExpenseReport.ForeColor = System.Drawing.Color.White;
            this.btnExpenseReport.Location = new System.Drawing.Point(207, 267);
            this.btnExpenseReport.Name = "btnExpenseReport";
            this.btnExpenseReport.Size = new System.Drawing.Size(443, 44);
            this.btnExpenseReport.TabIndex = 0;
            this.btnExpenseReport.Text = "Expense Report";
            this.btnExpenseReport.UseVisualStyleBackColor = false;
            this.btnExpenseReport.Click += new System.EventHandler(this.btnExpenseReport_Click);
            // 
            // frmReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExpenseReport);
            this.Controls.Add(this.btnStudReport);
            this.Controls.Add(this.btnFeesReport);
            this.Name = "frmReports";
            this.Text = "frmReports";
            this.ResumeLayout(false);

        }

        #endregion

        private myPrimaryBtn btnFeesReport;
        private myPrimaryBtn btnStudReport;
        private myPrimaryBtn btnExpenseReport;
    }
}