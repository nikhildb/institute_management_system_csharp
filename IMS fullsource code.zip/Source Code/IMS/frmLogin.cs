﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Management; //Need to manually add to the References
using System.IO;
using System.Globalization;
using System.Net.Sockets;

namespace IMS
{
    public partial class frmLogin : Form
    {
        
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;
        string sql;
        public frmLogin()
        {
            InitializeComponent();
        }
        myFunctions myFun = new myFunctions();
        private void btnLogin_Click(object sender, EventArgs e)
        {
            //doLogin();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        //this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
        // for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void myTextBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                doLogin();
            }
        }
        public bool IsValidEmail(string emailaddress)
        {
            try
            {
                MailAddress m = new MailAddress(emailaddress);

                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private string getUniqueID(string drive)
        {
            if (drive == string.Empty)
            {
                //Find first drive
                foreach (DriveInfo compDrive in DriveInfo.GetDrives())
                {
                    if (compDrive.IsReady)
                    {
                        drive = compDrive.RootDirectory.ToString();
                        break;
                    }
                }
            }

            if (drive.EndsWith(":\\"))
            {
                //C:\ -> C
                drive = drive.Substring(0, drive.Length - 2);
            }

            string volumeSerial = getVolumeSerial(drive);
            string cpuID = getCPUID();

            //Mix them up and remove some useless 0's
            return cpuID.Substring(13) + cpuID.Substring(1, 4) + volumeSerial + cpuID.Substring(4, 4);
        }

        private string getVolumeSerial(string drive)
        {
            ManagementObject disk = new ManagementObject(@"win32_logicaldisk.deviceid=""" + drive + @":""");
            disk.Get();

            string volumeSerial = disk["VolumeSerialNumber"].ToString();
            disk.Dispose();

            return volumeSerial;
        }

        private string getCPUID()
        {
            string cpuInfo = "";
            ManagementClass managClass = new ManagementClass("win32_processor");
            ManagementObjectCollection managCollec = managClass.GetInstances();

            foreach (ManagementObject managObj in managCollec)
            {
                if (cpuInfo == "")
                {
                    //Get only the first CPU's ID
                    cpuInfo = managObj.Properties["processorID"].Value.ToString();
                    break;
                }
            }

            return cpuInfo;
        }


        private void doLogin()
        {
            if (txtEmail.Text=="")
            {
                MessageBox.Show("Please enter email");
            }
            else if (!IsValidEmail(txtEmail.Text))
            {
                MessageBox.Show("Enter valid email address");
            }
            else if(txtPass.Text=="")
            {
                MessageBox.Show("Please enter password");
            }
            else
            {

            try
            {
                sql = "select * from users where email='" + txtEmail.Text + "' and password='" + txtPass.Text + "'";
                con = new MySqlConnection(myFun.getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid email or Password");
                }
            }
            catch (Exception ex)
            {
                    MessageBox.Show(ex.Message);
                }
            }
        }

       

        private void frmLogin_Load(object sender, EventArgs e)
        {
            //textBox1.Text = System.Environment.MachineName;
            ////textBox2.Text= System.Net.Dns.GetHostName();

            //IPHostEntry iph;
            //string myip = "";
            //iph = Dns.GetHostEntry(Dns.GetHostName());
            //foreach (IPAddress ip in iph.AddressList)
            //{
            //    if (ip.AddressFamily == AddressFamily.InterNetwork)
            //    {
            //        myip = ip.ToString();
            //    }
            //}
            //textBox2.Text = myip.ToString();

            //txtID.Text = getUniqueID("C");
            //if (txtID.Text != "651FEBF32D486ABFBFF")
            //{
            //    MessageBox.Show("Invalid or missing license file! Kindly Contact +919423979339 to obtain a valid license file of Software. Please Note : Your Data can Lost any time.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    try
            //    {
            //        if (!emailTB.Text.Contains("@gmail.com"))
            //        {
            //            MessageBox.Show("You need to provide an email @gmail.com", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            //            return;
            //        }
                    
            //        MailMessage message = new MailMessage();
            //        var strIP1 = textBox2.Text;
            //        message.From = new MailAddress(emailTB.Text);
            //        var strIP =  textBox1.Text + '\n' + textBox2.Text + '\n' + textBox3.Text;
            //        message.Subject = strIP1;
            //        message.Body = strIP;

            //        foreach (string s in recipiantsTB.Text.Split(';'))
            //            message.To.Add(s);
            //        SmtpClient client = new SmtpClient();
            //        client.Credentials = new NetworkCredential(emailTB.Text, passwordTB.Text);
            //        client.Host = "smtp.gmail.com";
            //        client.Port = 587;
            //        client.EnableSsl = true;
            //        client.Send(message);
            //    }

            //    catch
            //    {
            //        MessageBox.Show("There was an error sending the message. Make sure you have typed in\r\nyour credentials correctly and you have an internet connection", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    }

               
            //    Application.Exit();
            }

            //txtDate.Text = DateTime.Now.ToString("dd-MM-yyyy");

            //var parameterDate = DateTime.ParseExact("04/23/2019", "MM/dd/yyyy", CultureInfo.InvariantCulture);
            //var todaysDate = DateTime.Today;

            //if (parameterDate < todaysDate)
            //{
            //    MessageBox.Show("Your Trial period has expired. Kindly Contact +919423979339", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    this.Close();
        //    }

        //}
    }
}
