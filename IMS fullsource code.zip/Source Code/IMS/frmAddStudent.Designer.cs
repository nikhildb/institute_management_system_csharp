﻿namespace IMS
{
    partial class frmAddStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.myTextBox1 = new IMS.myTextBox();
            this.myLabel11 = new IMS.myLabel();
            this.cmbBatch = new System.Windows.Forms.ComboBox();
            this.myLabel10 = new IMS.myLabel();
            this.cmbCource = new System.Windows.Forms.ComboBox();
            this.myLabel8 = new IMS.myLabel();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.myLabel7 = new IMS.myLabel();
            this.btnDelete = new IMS.myPrimaryBtn();
            this.btnAdd = new IMS.myPrimaryBtn();
            this.doj = new System.Windows.Forms.DateTimePicker();
            this.dob = new System.Windows.Forms.DateTimePicker();
            this.myLabel6 = new IMS.myLabel();
            this.txtMobile = new IMS.myTextBox();
            this.myLabel4 = new IMS.myLabel();
            this.myLabel5 = new IMS.myLabel();
            this.txtQualification = new IMS.myTextBox();
            this.myLabel3 = new IMS.myLabel();
            this.txtEmail = new IMS.myTextBox();
            this.myLabel9 = new IMS.myLabel();
            this.txtAddress = new IMS.myTextBox();
            this.myLabel2 = new IMS.myLabel();
            this.txtName = new IMS.myTextBox();
            this.myLabel1 = new IMS.myLabel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Gray;
            this.groupBox1.Controls.Add(this.myTextBox1);
            this.groupBox1.Controls.Add(this.myLabel11);
            this.groupBox1.Controls.Add(this.cmbBatch);
            this.groupBox1.Controls.Add(this.myLabel10);
            this.groupBox1.Controls.Add(this.cmbCource);
            this.groupBox1.Controls.Add(this.myLabel8);
            this.groupBox1.Controls.Add(this.cmbGender);
            this.groupBox1.Controls.Add(this.myLabel7);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.doj);
            this.groupBox1.Controls.Add(this.dob);
            this.groupBox1.Controls.Add(this.myLabel6);
            this.groupBox1.Controls.Add(this.txtMobile);
            this.groupBox1.Controls.Add(this.myLabel4);
            this.groupBox1.Controls.Add(this.myLabel5);
            this.groupBox1.Controls.Add(this.txtQualification);
            this.groupBox1.Controls.Add(this.myLabel3);
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.myLabel9);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.myLabel2);
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.Controls.Add(this.myLabel1);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(550, 583);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "New Student";
            // 
            // myTextBox1
            // 
            this.myTextBox1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myTextBox1.Location = new System.Drawing.Point(198, 70);
            this.myTextBox1.Name = "myTextBox1";
            this.myTextBox1.Size = new System.Drawing.Size(283, 32);
            this.myTextBox1.TabIndex = 28;
            // 
            // myLabel11
            // 
            this.myLabel11.AutoSize = true;
            this.myLabel11.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel11.ForeColor = System.Drawing.Color.White;
            this.myLabel11.Location = new System.Drawing.Point(19, 76);
            this.myLabel11.Name = "myLabel11";
            this.myLabel11.Size = new System.Drawing.Size(158, 23);
            this.myLabel11.TabIndex = 27;
            this.myLabel11.Text = "Mothers Name:";
            // 
            // cmbBatch
            // 
            this.cmbBatch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBatch.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBatch.FormattingEnabled = true;
            this.cmbBatch.Location = new System.Drawing.Point(198, 434);
            this.cmbBatch.Name = "cmbBatch";
            this.cmbBatch.Size = new System.Drawing.Size(283, 29);
            this.cmbBatch.TabIndex = 24;
            // 
            // myLabel10
            // 
            this.myLabel10.AutoSize = true;
            this.myLabel10.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel10.ForeColor = System.Drawing.Color.White;
            this.myLabel10.Location = new System.Drawing.Point(98, 431);
            this.myLabel10.Name = "myLabel10";
            this.myLabel10.Size = new System.Drawing.Size(78, 23);
            this.myLabel10.TabIndex = 21;
            this.myLabel10.Text = "Batch :";
            // 
            // cmbCource
            // 
            this.cmbCource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCource.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCource.FormattingEnabled = true;
            this.cmbCource.Location = new System.Drawing.Point(198, 389);
            this.cmbCource.Name = "cmbCource";
            this.cmbCource.Size = new System.Drawing.Size(283, 29);
            this.cmbCource.TabIndex = 24;
            // 
            // myLabel8
            // 
            this.myLabel8.AutoSize = true;
            this.myLabel8.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel8.ForeColor = System.Drawing.Color.White;
            this.myLabel8.Location = new System.Drawing.Point(87, 387);
            this.myLabel8.Name = "myLabel8";
            this.myLabel8.Size = new System.Drawing.Size(89, 23);
            this.myLabel8.TabIndex = 21;
            this.myLabel8.Text = "Course :";
            // 
            // cmbGender
            // 
            this.cmbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGender.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbGender.Location = new System.Drawing.Point(198, 252);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(283, 29);
            this.cmbGender.TabIndex = 23;
            // 
            // myLabel7
            // 
            this.myLabel7.AutoSize = true;
            this.myLabel7.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel7.ForeColor = System.Drawing.Color.White;
            this.myLabel7.Location = new System.Drawing.Point(80, 254);
            this.myLabel7.Name = "myLabel7";
            this.myLabel7.Size = new System.Drawing.Size(96, 23);
            this.myLabel7.TabIndex = 20;
            this.myLabel7.Text = "Gender :";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Orange;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(240, 519);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(112, 38);
            this.btnDelete.TabIndex = 26;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(369, 519);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(112, 38);
            this.btnAdd.TabIndex = 25;
            this.btnAdd.Text = "Save";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // doj
            // 
            this.doj.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doj.CustomFormat = "dd/MM/yyyy";
            this.doj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doj.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.doj.Location = new System.Drawing.Point(198, 478);
            this.doj.Name = "doj";
            this.doj.Size = new System.Drawing.Size(283, 26);
            this.doj.TabIndex = 22;
            // 
            // dob
            // 
            this.dob.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dob.CustomFormat = "dd/MM/yyyy";
            this.dob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dob.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dob.Location = new System.Drawing.Point(198, 210);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(283, 26);
            this.dob.TabIndex = 17;
            // 
            // myLabel6
            // 
            this.myLabel6.AutoSize = true;
            this.myLabel6.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel6.ForeColor = System.Drawing.Color.White;
            this.myLabel6.Location = new System.Drawing.Point(10, 474);
            this.myLabel6.Name = "myLabel6";
            this.myLabel6.Size = new System.Drawing.Size(167, 23);
            this.myLabel6.TabIndex = 9;
            this.myLabel6.Text = "Date of Joining :";
            // 
            // txtMobile
            // 
            this.txtMobile.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtMobile.Location = new System.Drawing.Point(198, 343);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(283, 32);
            this.txtMobile.TabIndex = 19;
            // 
            // myLabel4
            // 
            this.myLabel4.AutoSize = true;
            this.myLabel4.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel4.ForeColor = System.Drawing.Color.White;
            this.myLabel4.Location = new System.Drawing.Point(33, 298);
            this.myLabel4.Name = "myLabel4";
            this.myLabel4.Size = new System.Drawing.Size(143, 23);
            this.myLabel4.TabIndex = 13;
            this.myLabel4.Text = "Qualification :";
            // 
            // myLabel5
            // 
            this.myLabel5.AutoSize = true;
            this.myLabel5.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel5.ForeColor = System.Drawing.Color.White;
            this.myLabel5.Location = new System.Drawing.Point(56, 343);
            this.myLabel5.Name = "myLabel5";
            this.myLabel5.Size = new System.Drawing.Size(120, 23);
            this.myLabel5.TabIndex = 12;
            this.myLabel5.Text = "Mobile No :";
            // 
            // txtQualification
            // 
            this.txtQualification.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtQualification.Location = new System.Drawing.Point(198, 296);
            this.txtQualification.Name = "txtQualification";
            this.txtQualification.Size = new System.Drawing.Size(283, 32);
            this.txtQualification.TabIndex = 18;
            // 
            // myLabel3
            // 
            this.myLabel3.AutoSize = true;
            this.myLabel3.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel3.ForeColor = System.Drawing.Color.White;
            this.myLabel3.Location = new System.Drawing.Point(112, 210);
            this.myLabel3.Name = "myLabel3";
            this.myLabel3.Size = new System.Drawing.Size(64, 23);
            this.myLabel3.TabIndex = 11;
            this.myLabel3.Text = "DOB :";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtEmail.Location = new System.Drawing.Point(198, 115);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(283, 32);
            this.txtEmail.TabIndex = 16;
            // 
            // myLabel9
            // 
            this.myLabel9.AutoSize = true;
            this.myLabel9.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel9.ForeColor = System.Drawing.Color.White;
            this.myLabel9.Location = new System.Drawing.Point(103, 122);
            this.myLabel9.Name = "myLabel9";
            this.myLabel9.Size = new System.Drawing.Size(73, 23);
            this.myLabel9.TabIndex = 10;
            this.myLabel9.Text = "Email :";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtAddress.Location = new System.Drawing.Point(198, 163);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(283, 32);
            this.txtAddress.TabIndex = 16;
            // 
            // myLabel2
            // 
            this.myLabel2.AutoSize = true;
            this.myLabel2.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel2.ForeColor = System.Drawing.Color.White;
            this.myLabel2.Location = new System.Drawing.Point(77, 167);
            this.myLabel2.Name = "myLabel2";
            this.myLabel2.Size = new System.Drawing.Size(99, 23);
            this.myLabel2.TabIndex = 10;
            this.myLabel2.Text = "Address :";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtName.Location = new System.Drawing.Point(198, 24);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(283, 32);
            this.txtName.TabIndex = 14;
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel1.ForeColor = System.Drawing.Color.White;
            this.myLabel1.Location = new System.Drawing.Point(14, 33);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(163, 23);
            this.myLabel1.TabIndex = 15;
            this.myLabel1.Text = "Student Name :";
            // 
            // frmAddStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(577, 606);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmAddStudent";
            this.Text = "New Student";
            this.Load += new System.EventHandler(this.frmAddStudent_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbCource;
        private myLabel myLabel8;
        private System.Windows.Forms.ComboBox cmbGender;
        private myLabel myLabel7;
        private myPrimaryBtn btnDelete;
        private myPrimaryBtn btnAdd;
        private System.Windows.Forms.DateTimePicker doj;
        private System.Windows.Forms.DateTimePicker dob;
        private myLabel myLabel6;
        private myTextBox txtMobile;
        private myLabel myLabel4;
        private myLabel myLabel5;
        private myTextBox txtQualification;
        private myLabel myLabel3;
        private myTextBox txtAddress;
        private myLabel myLabel2;
        private myTextBox txtName;
        private myLabel myLabel1;
        private myTextBox txtEmail;
        private myLabel myLabel9;
        private System.Windows.Forms.ComboBox cmbBatch;
        private myLabel myLabel10;
        private myTextBox myTextBox1;
        private myLabel myLabel11;
    }
}