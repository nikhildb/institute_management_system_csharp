﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class myPrimaryBtn : Button
    {
        public myPrimaryBtn()
        {
            InitializeComponent();
            this.Font = new Font("Century Gothic", 15, FontStyle.Regular);
            BackColor = Color.FromName("LightSeaGreen");
            ForeColor = Color.White;
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            Height = 30;
            Width = 100;
            Cursor = Cursors.Hand;
            
        }
    }
}
