﻿namespace IMS
{
    partial class frmEnquiryMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnAddEnquiry = new IMS.myPrimaryBtn();
            this.myLabel1 = new IMS.myLabel();
            this.dgvEnquiry = new IMS.myGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEnquiry)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddEnquiry
            // 
            this.btnAddEnquiry.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddEnquiry.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnAddEnquiry.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAddEnquiry.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddEnquiry.FlatAppearance.BorderSize = 0;
            this.btnAddEnquiry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddEnquiry.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnAddEnquiry.ForeColor = System.Drawing.Color.White;
            this.btnAddEnquiry.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddEnquiry.Location = new System.Drawing.Point(611, 116);
            this.btnAddEnquiry.Name = "btnAddEnquiry";
            this.btnAddEnquiry.Size = new System.Drawing.Size(167, 44);
            this.btnAddEnquiry.TabIndex = 2;
            this.btnAddEnquiry.Text = "New Enquiry";
            this.btnAddEnquiry.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnAddEnquiry.UseVisualStyleBackColor = false;
            this.btnAddEnquiry.Click += new System.EventHandler(this.btnAddEnquiry_Click);
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myLabel1.ForeColor = System.Drawing.Color.White;
            this.myLabel1.Location = new System.Drawing.Point(302, 55);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(182, 28);
            this.myLabel1.TabIndex = 3;
            this.myLabel1.Text = "Enquiry Master";
            // 
            // dgvEnquiry
            // 
            this.dgvEnquiry.AllowUserToAddRows = false;
            this.dgvEnquiry.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEnquiry.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(2);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEnquiry.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvEnquiry.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEnquiry.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvEnquiry.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvEnquiry.EnableHeadersVisualStyles = false;
            this.dgvEnquiry.GridColor = System.Drawing.Color.White;
            this.dgvEnquiry.Location = new System.Drawing.Point(0, 166);
            this.dgvEnquiry.MultiSelect = false;
            this.dgvEnquiry.Name = "dgvEnquiry";
            this.dgvEnquiry.ReadOnly = true;
            this.dgvEnquiry.RowHeadersVisible = false;
            this.dgvEnquiry.RowTemplate.Height = 50;
            this.dgvEnquiry.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEnquiry.Size = new System.Drawing.Size(790, 284);
            this.dgvEnquiry.TabIndex = 0;
            this.dgvEnquiry.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEnquiry_CellDoubleClick);
            this.dgvEnquiry.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvEnquiry_KeyDown);
            // 
            // frmEnquiryMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(790, 450);
            this.Controls.Add(this.dgvEnquiry);
            this.Controls.Add(this.myLabel1);
            this.Controls.Add(this.btnAddEnquiry);
            this.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmEnquiryMaster";
            this.Text = "Enquiry Master";
            this.Load += new System.EventHandler(this.frmEnquiryMaster_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEnquiry)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private myPrimaryBtn btnAddEnquiry;
        private myLabel myLabel1;
        private myGridView dgvEnquiry;
    }
}