﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmFeesMaster : myForm
    {
        string sql = "select * from fees";
        myFunctions myFun = new myFunctions();
        MySqlConnection con;
        MySqlDataAdapter adapter;
        DataTable table;
        public frmFeesMaster()
        {
            InitializeComponent();
        }

        private void btnDepositFee_Click(object sender, EventArgs e)
        {
            frmDepositFee f = new frmDepositFee();
            f.ShowDialog();
            refreshGrid(sql);
        }
        private void refreshGrid(string query)
        {
            try
            {
                con = new MySqlConnection(myFun.getstring());

                adapter = new MySqlDataAdapter(query, con);
                //cmdBuilder = new MySqlCommandBuilder(adapter);
                table = new DataTable();
                table.Clear();
                adapter.Fill(table);
                //if (table.Rows.Count > 0)
                dgvFees.DataSource = table;
                dgvFees.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvFees.Columns[0].Width = 100;
                dgvFees.Columns[1].Width = 250;
                dgvFees.Columns[2].Width = 150;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void frmFeesMaster_Load(object sender, EventArgs e)
        {
            refreshGrid(sql);
        }
    }
}
