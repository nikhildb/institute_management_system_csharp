﻿namespace IMS
{
    partial class frmAddExpense
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myLabel1 = new IMS.myLabel();
            this.txtAmt = new IMS.myTextBox();
            this.myLabel2 = new IMS.myLabel();
            this.cmbPaymentMode = new IMS.myComboBox();
            this.myLabel3 = new IMS.myLabel();
            this.myLabel4 = new IMS.myLabel();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.txtNote = new IMS.myTextBox();
            this.btnAddExpense = new IMS.myPrimaryBtn();
            this.myLabel5 = new IMS.myLabel();
            this.txtTitle = new IMS.myTextBox();
            this.btnDelete = new IMS.myPrimaryBtn();
            this.SuspendLayout();
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel1.ForeColor = System.Drawing.Color.White;
            this.myLabel1.Location = new System.Drawing.Point(51, 90);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(99, 23);
            this.myLabel1.TabIndex = 0;
            this.myLabel1.Text = "Amount :";
            // 
            // txtAmt
            // 
            this.txtAmt.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtAmt.Location = new System.Drawing.Point(228, 90);
            this.txtAmt.Name = "txtAmt";
            this.txtAmt.Size = new System.Drawing.Size(160, 32);
            this.txtAmt.TabIndex = 1;
            // 
            // myLabel2
            // 
            this.myLabel2.AutoSize = true;
            this.myLabel2.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel2.ForeColor = System.Drawing.Color.White;
            this.myLabel2.Location = new System.Drawing.Point(51, 151);
            this.myLabel2.Name = "myLabel2";
            this.myLabel2.Size = new System.Drawing.Size(172, 23);
            this.myLabel2.TabIndex = 2;
            this.myLabel2.Text = "Payment Mode :";
            // 
            // cmbPaymentMode
            // 
            this.cmbPaymentMode.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.cmbPaymentMode.FormattingEnabled = true;
            this.cmbPaymentMode.Location = new System.Drawing.Point(228, 143);
            this.cmbPaymentMode.Name = "cmbPaymentMode";
            this.cmbPaymentMode.Size = new System.Drawing.Size(160, 31);
            this.cmbPaymentMode.TabIndex = 3;
            // 
            // myLabel3
            // 
            this.myLabel3.AutoSize = true;
            this.myLabel3.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel3.ForeColor = System.Drawing.Color.White;
            this.myLabel3.Location = new System.Drawing.Point(55, 197);
            this.myLabel3.Name = "myLabel3";
            this.myLabel3.Size = new System.Drawing.Size(70, 23);
            this.myLabel3.TabIndex = 4;
            this.myLabel3.Text = "Date :";
            // 
            // myLabel4
            // 
            this.myLabel4.AutoSize = true;
            this.myLabel4.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel4.ForeColor = System.Drawing.Color.White;
            this.myLabel4.Location = new System.Drawing.Point(51, 251);
            this.myLabel4.Name = "myLabel4";
            this.myLabel4.Size = new System.Drawing.Size(69, 23);
            this.myLabel4.TabIndex = 5;
            this.myLabel4.Text = "Note :";
            // 
            // date
            // 
            this.date.CustomFormat = "dd/MM/yyyy";
            this.date.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date.Location = new System.Drawing.Point(228, 197);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(160, 27);
            this.date.TabIndex = 6;
            // 
            // txtNote
            // 
            this.txtNote.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtNote.Location = new System.Drawing.Point(228, 251);
            this.txtNote.Multiline = true;
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(240, 113);
            this.txtNote.TabIndex = 7;
            // 
            // btnAddExpense
            // 
            this.btnAddExpense.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnAddExpense.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddExpense.FlatAppearance.BorderSize = 0;
            this.btnAddExpense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddExpense.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnAddExpense.ForeColor = System.Drawing.Color.White;
            this.btnAddExpense.Location = new System.Drawing.Point(228, 375);
            this.btnAddExpense.Name = "btnAddExpense";
            this.btnAddExpense.Size = new System.Drawing.Size(160, 37);
            this.btnAddExpense.TabIndex = 8;
            this.btnAddExpense.Text = "Save";
            this.btnAddExpense.UseVisualStyleBackColor = false;
            this.btnAddExpense.Click += new System.EventHandler(this.btnAddExpense_Click);
            // 
            // myLabel5
            // 
            this.myLabel5.AutoSize = true;
            this.myLabel5.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel5.ForeColor = System.Drawing.Color.White;
            this.myLabel5.Location = new System.Drawing.Point(51, 43);
            this.myLabel5.Name = "myLabel5";
            this.myLabel5.Size = new System.Drawing.Size(144, 23);
            this.myLabel5.TabIndex = 0;
            this.myLabel5.Text = "Expense Title :";
            // 
            // txtTitle
            // 
            this.txtTitle.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtTitle.Location = new System.Drawing.Point(228, 43);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(160, 32);
            this.txtTitle.TabIndex = 1;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Orange;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(393, 375);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(103, 37);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // frmAddExpense
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(505, 429);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAddExpense);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.date);
            this.Controls.Add(this.myLabel4);
            this.Controls.Add(this.myLabel3);
            this.Controls.Add(this.cmbPaymentMode);
            this.Controls.Add(this.myLabel2);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.myLabel5);
            this.Controls.Add(this.txtAmt);
            this.Controls.Add(this.myLabel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmAddExpense";
            this.Text = "frmAddExpense";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private myLabel myLabel1;
        private myTextBox txtAmt;
        private myLabel myLabel2;
        private myComboBox cmbPaymentMode;
        private myLabel myLabel3;
        private myLabel myLabel4;
        private System.Windows.Forms.DateTimePicker date;
        private myTextBox txtNote;
        private myPrimaryBtn btnAddExpense;
        private myLabel myLabel5;
        private myTextBox txtTitle;
        private myPrimaryBtn btnDelete;
    }
}