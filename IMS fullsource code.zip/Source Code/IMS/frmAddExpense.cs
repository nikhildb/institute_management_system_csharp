﻿using System;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmAddExpense : myForm
    {
        string sql;
        int id;
        public frmAddExpense()
        {
            InitializeComponent();
            this.id = id;
           // btnDelete.Visible = false;

        }

        public frmAddExpense(int id)
        {
            this.id = id;
        }

        myFunctions myfun = new myFunctions();
        private void btnAddExpense_Click(object sender, EventArgs e)
        {
            if (txtTitle.Text == "")
            {
                MessageBox.Show("Enter expense title");
                txtTitle.Focus();
            }
            else if (txtAmt.Text == "")
            {
                MessageBox.Show("Enter amount");
                txtAmt.Focus();
            }
            else
            {

            sql = "insert into expenses(expense_title,amt,payment_mode,date,note) " +
                "values('"+txtTitle.Text+"'," +
                "'"+txtAmt.Text+"'," +
                "'"+cmbPaymentMode.Text+"'," +
                "'" + System.DateTime.Now.ToString("yyyy-MM-dd") + "'," +
                "'" +txtNote.Text+"')";
            myfun.Query(sql, "Expense added successfully !");
            this.Close();

            }
        }
        //this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
        // for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com

        private void btnDelete_Click(object sender, EventArgs e)
        {
            sql = "delete from 	expenses where id=" + id;
        }
    }
}
