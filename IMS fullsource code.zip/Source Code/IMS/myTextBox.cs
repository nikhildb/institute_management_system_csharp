﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class myTextBox : TextBox
    {
        public myTextBox()
        {
            InitializeComponent();
            this.Font= new Font("Century Gothic",15,FontStyle.Regular);
            this.Height = 30;
            this.Width = 160;
        }
    }
}
