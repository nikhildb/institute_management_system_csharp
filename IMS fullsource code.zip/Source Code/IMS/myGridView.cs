﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class myGridView : DataGridView
    {
        public myGridView()
        {
            InitializeComponent();
            
            System.Windows.Forms.DataGridViewCellStyle dgvStyle = new System.Windows.Forms.DataGridViewCellStyle();
            this.AllowUserToAddRows = false;
            this.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ColumnHeadersDefaultCellStyle = dgvStyle;
            this.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            RowTemplate.Height = 50;
            dgvStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dgvStyle.BackColor = System.Drawing.SystemColors.Window;
            dgvStyle.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dgvStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            dgvStyle.Padding = new System.Windows.Forms.Padding(2);
            dgvStyle.SelectionBackColor = System.Drawing.Color.Gray;
            dgvStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dgvStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DefaultCellStyle = dgvStyle;
            this.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.EnableHeadersVisualStyles = false;
            this.GridColor = System.Drawing.Color.White;
            this.Location = new System.Drawing.Point(0, 99);
            this.MultiSelect = false;
            this.Name = "dataGridView1";
            this.ReadOnly = true;
            this.RowHeadersVisible = false;
            this.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Size = new System.Drawing.Size(790, 428);
            this.TabIndex = 0;
            BorderStyle = BorderStyle.FixedSingle;
            CellBorderStyle = DataGridViewCellBorderStyle.Raised;


        }
    }
}
