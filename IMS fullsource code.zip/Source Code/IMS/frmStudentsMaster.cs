﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmStudentsMaster : myForm
    {
        string sql="select id, name, mname, email, course, batch, doj, dob, qualification, address, mobile, gender from students";
        myFunctions myFun = new myFunctions();
        MySqlConnection con;
        //MySqlCommand cmd;
        //MySqlDataReader reader;
        MySqlDataAdapter adapter;
        DataTable table;
        public frmStudentsMaster()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frmStudentsMaster_Load(object sender, EventArgs e)
        {
           
            refreshGrid(sql);
        }
        private void refreshGrid(string query)
        {
            try
            {
                con = new MySqlConnection(myFun.getstring());
                adapter = new MySqlDataAdapter(query, con);
                table = new DataTable();
                table.Clear();
                adapter.Fill(table);
                //if (table.Rows.Count > 0)
                myGridView1.DataSource = table;
                myGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                myGridView1.Columns[0].Width = 50;
                myGridView1.Columns[1].Width = 300;
                myGridView1.Columns[2].Width = 300;
                myGridView1.Columns[3].Width = 200;
                myGridView1.Columns[4].Width = 150;
                myGridView1.Columns[5].Width = 150;
                myGridView1.Columns[6].Width = 150;
                myGridView1.Columns[7].Width = 150;
                myGridView1.Columns[8].Width = 150;
                myGridView1.Columns[9].Width = 150;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtStudentSearch_TextChanged(object sender, EventArgs e)
        {
            string query = "select * from students where name like '%" + txtStudentSearch.Text + "%'";
            refreshGrid(query);
        }

        private void btnNewStudent_Click(object sender, EventArgs e)
        {
            frmAddStudent f = new frmAddStudent(0);
            f.ShowDialog();
            refreshGrid(sql);
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                editStudent();
            }
            
        }

        private void editStudent()
        {
            int id = int.Parse(myGridView1.SelectedCells[0].Value.ToString());
            //MessageBox.Show(id.ToString());
            frmAddStudent f = new frmAddStudent(id);
            f.ShowDialog();
            refreshGrid(sql);
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            editStudent();
        }

    }
}
