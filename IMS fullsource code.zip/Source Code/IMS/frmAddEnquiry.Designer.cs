﻿namespace IMS
{
    partial class frmAddEnquiry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myLabel1 = new IMS.myLabel();
            this.txtName = new IMS.myTextBox();
            this.myLabel2 = new IMS.myLabel();
            this.txtEmail = new IMS.myTextBox();
            this.myLabel3 = new IMS.myLabel();
            this.txtMobile = new IMS.myTextBox();
            this.myLabel4 = new IMS.myLabel();
            this.txtAddress = new IMS.myTextBox();
            this.myLabel5 = new IMS.myLabel();
            this.cmbCourse = new IMS.myComboBox();
            this.dtEnquiryDate = new System.Windows.Forms.DateTimePicker();
            this.myLabel6 = new IMS.myLabel();
            this.myLabel7 = new IMS.myLabel();
            this.txtRemark = new IMS.myTextBox();
            this.btnSave = new IMS.myPrimaryBtn();
            this.myLabel8 = new IMS.myLabel();
            this.myLabel9 = new IMS.myLabel();
            this.dtFolloup = new System.Windows.Forms.DateTimePicker();
            this.btnDelete = new IMS.myPrimaryBtn();
            this.btnToAdmission = new IMS.myPrimaryBtn();
            this.SuspendLayout();
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel1.ForeColor = System.Drawing.Color.White;
            this.myLabel1.Location = new System.Drawing.Point(23, 75);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(82, 23);
            this.myLabel1.TabIndex = 0;
            this.myLabel1.Text = "Name :";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtName.Location = new System.Drawing.Point(201, 65);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(289, 32);
            this.txtName.TabIndex = 1;
            // 
            // myLabel2
            // 
            this.myLabel2.AutoSize = true;
            this.myLabel2.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel2.ForeColor = System.Drawing.Color.White;
            this.myLabel2.Location = new System.Drawing.Point(23, 126);
            this.myLabel2.Name = "myLabel2";
            this.myLabel2.Size = new System.Drawing.Size(73, 23);
            this.myLabel2.TabIndex = 0;
            this.myLabel2.Text = "Email :";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtEmail.Location = new System.Drawing.Point(201, 116);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(289, 32);
            this.txtEmail.TabIndex = 1;
            // 
            // myLabel3
            // 
            this.myLabel3.AutoSize = true;
            this.myLabel3.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel3.ForeColor = System.Drawing.Color.White;
            this.myLabel3.Location = new System.Drawing.Point(23, 178);
            this.myLabel3.Name = "myLabel3";
            this.myLabel3.Size = new System.Drawing.Size(86, 23);
            this.myLabel3.TabIndex = 0;
            this.myLabel3.Text = "Mobile :";
            // 
            // txtMobile
            // 
            this.txtMobile.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtMobile.Location = new System.Drawing.Point(201, 168);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(289, 32);
            this.txtMobile.TabIndex = 1;
            // 
            // myLabel4
            // 
            this.myLabel4.AutoSize = true;
            this.myLabel4.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel4.ForeColor = System.Drawing.Color.White;
            this.myLabel4.Location = new System.Drawing.Point(23, 230);
            this.myLabel4.Name = "myLabel4";
            this.myLabel4.Size = new System.Drawing.Size(99, 23);
            this.myLabel4.TabIndex = 0;
            this.myLabel4.Text = "Address :";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtAddress.Location = new System.Drawing.Point(201, 220);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(289, 32);
            this.txtAddress.TabIndex = 1;
            // 
            // myLabel5
            // 
            this.myLabel5.AutoSize = true;
            this.myLabel5.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel5.ForeColor = System.Drawing.Color.White;
            this.myLabel5.Location = new System.Drawing.Point(23, 288);
            this.myLabel5.Name = "myLabel5";
            this.myLabel5.Size = new System.Drawing.Size(89, 23);
            this.myLabel5.TabIndex = 0;
            this.myLabel5.Text = "Course :";
            // 
            // cmbCourse
            // 
            this.cmbCourse.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.cmbCourse.FormattingEnabled = true;
            this.cmbCourse.Location = new System.Drawing.Point(201, 279);
            this.cmbCourse.Name = "cmbCourse";
            this.cmbCourse.Size = new System.Drawing.Size(289, 31);
            this.cmbCourse.TabIndex = 2;
            // 
            // dtEnquiryDate
            // 
            this.dtEnquiryDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtEnquiryDate.CustomFormat = "dd/MM/yyyy";
            this.dtEnquiryDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtEnquiryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtEnquiryDate.Location = new System.Drawing.Point(200, 327);
            this.dtEnquiryDate.Name = "dtEnquiryDate";
            this.dtEnquiryDate.Size = new System.Drawing.Size(283, 26);
            this.dtEnquiryDate.TabIndex = 18;
            // 
            // myLabel6
            // 
            this.myLabel6.AutoSize = true;
            this.myLabel6.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel6.ForeColor = System.Drawing.Color.White;
            this.myLabel6.Location = new System.Drawing.Point(20, 330);
            this.myLabel6.Name = "myLabel6";
            this.myLabel6.Size = new System.Drawing.Size(145, 23);
            this.myLabel6.TabIndex = 0;
            this.myLabel6.Text = "Enquiry Date :";
            // 
            // myLabel7
            // 
            this.myLabel7.AutoSize = true;
            this.myLabel7.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel7.ForeColor = System.Drawing.Color.White;
            this.myLabel7.Location = new System.Drawing.Point(23, 403);
            this.myLabel7.Name = "myLabel7";
            this.myLabel7.Size = new System.Drawing.Size(95, 23);
            this.myLabel7.TabIndex = 0;
            this.myLabel7.Text = "Remark :";
            // 
            // txtRemark
            // 
            this.txtRemark.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.txtRemark.Location = new System.Drawing.Point(201, 400);
            this.txtRemark.Multiline = true;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(289, 61);
            this.txtRemark.TabIndex = 1;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(272, 489);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(121, 46);
            this.btnSave.TabIndex = 19;
            this.btnSave.Text = "Add";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // myLabel8
            // 
            this.myLabel8.AutoSize = true;
            this.myLabel8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myLabel8.ForeColor = System.Drawing.Color.White;
            this.myLabel8.Location = new System.Drawing.Point(159, 9);
            this.myLabel8.Name = "myLabel8";
            this.myLabel8.Size = new System.Drawing.Size(182, 28);
            this.myLabel8.TabIndex = 20;
            this.myLabel8.Text = "Enquiry Master";
            // 
            // myLabel9
            // 
            this.myLabel9.AutoSize = true;
            this.myLabel9.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.myLabel9.ForeColor = System.Drawing.Color.White;
            this.myLabel9.Location = new System.Drawing.Point(21, 371);
            this.myLabel9.Name = "myLabel9";
            this.myLabel9.Size = new System.Drawing.Size(148, 23);
            this.myLabel9.TabIndex = 0;
            this.myLabel9.Text = "Folloup Date :";
            // 
            // dtFolloup
            // 
            this.dtFolloup.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtFolloup.CustomFormat = "dd/MM/yyyy";
            this.dtFolloup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtFolloup.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtFolloup.Location = new System.Drawing.Point(201, 368);
            this.dtFolloup.Name = "dtFolloup";
            this.dtFolloup.Size = new System.Drawing.Size(283, 26);
            this.dtFolloup.TabIndex = 18;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.DarkOrange;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(399, 489);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(121, 46);
            this.btnDelete.TabIndex = 19;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnToAdmission
            // 
            this.btnToAdmission.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnToAdmission.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnToAdmission.FlatAppearance.BorderSize = 0;
            this.btnToAdmission.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToAdmission.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnToAdmission.ForeColor = System.Drawing.Color.White;
            this.btnToAdmission.Location = new System.Drawing.Point(12, 489);
            this.btnToAdmission.Name = "btnToAdmission";
            this.btnToAdmission.Size = new System.Drawing.Size(254, 46);
            this.btnToAdmission.TabIndex = 19;
            this.btnToAdmission.Text = "Convert To Admission";
            this.btnToAdmission.UseVisualStyleBackColor = false;
            this.btnToAdmission.Click += new System.EventHandler(this.btnToAdmission_Click);
            // 
            // frmAddEnquiry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(532, 547);
            this.Controls.Add(this.myLabel8);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnToAdmission);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dtFolloup);
            this.Controls.Add(this.dtEnquiryDate);
            this.Controls.Add(this.cmbCourse);
            this.Controls.Add(this.myLabel9);
            this.Controls.Add(this.myLabel7);
            this.Controls.Add(this.myLabel6);
            this.Controls.Add(this.myLabel5);
            this.Controls.Add(this.txtRemark);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.myLabel4);
            this.Controls.Add(this.txtMobile);
            this.Controls.Add(this.myLabel3);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.myLabel2);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.myLabel1);
            this.Name = "frmAddEnquiry";
            this.Text = "Enquiry Form";
            this.Load += new System.EventHandler(this.frmAddEnquiry_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private myLabel myLabel1;
        private myTextBox txtName;
        private myLabel myLabel2;
        private myTextBox txtEmail;
        private myLabel myLabel3;
        private myTextBox txtMobile;
        private myLabel myLabel4;
        private myTextBox txtAddress;
        private myLabel myLabel5;
        private myComboBox cmbCourse;
        private System.Windows.Forms.DateTimePicker dtEnquiryDate;
        private myLabel myLabel6;
        private myLabel myLabel7;
        private myTextBox txtRemark;
        private myPrimaryBtn btnSave;
        private myLabel myLabel8;
        private myLabel myLabel9;
        private System.Windows.Forms.DateTimePicker dtFolloup;
        private myPrimaryBtn btnDelete;
        private myPrimaryBtn btnToAdmission;
    }
}