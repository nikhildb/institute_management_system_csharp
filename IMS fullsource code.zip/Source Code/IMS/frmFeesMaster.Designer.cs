﻿namespace IMS
{
    partial class frmFeesMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvFees = new IMS.myGridView();
            this.myLabel1 = new IMS.myLabel();
            this.btnDepositFee = new IMS.myPrimaryBtn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvFees
            // 
            this.dgvFees.AllowUserToAddRows = false;
            this.dgvFees.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvFees.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(2);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvFees.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFees.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFees.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvFees.EnableHeadersVisualStyles = false;
            this.dgvFees.GridColor = System.Drawing.Color.White;
            this.dgvFees.Location = new System.Drawing.Point(1, 116);
            this.dgvFees.MultiSelect = false;
            this.dgvFees.Name = "dgvFees";
            this.dgvFees.ReadOnly = true;
            this.dgvFees.RowHeadersVisible = false;
            this.dgvFees.RowTemplate.Height = 50;
            this.dgvFees.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFees.Size = new System.Drawing.Size(798, 336);
            this.dgvFees.TabIndex = 0;
            // 
            // myLabel1
            // 
            this.myLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myLabel1.ForeColor = System.Drawing.Color.White;
            this.myLabel1.Location = new System.Drawing.Point(193, 29);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(275, 32);
            this.myLabel1.TabIndex = 1;
            this.myLabel1.Text = "Student Fees Master";
            // 
            // btnDepositFee
            // 
            this.btnDepositFee.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnDepositFee.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDepositFee.FlatAppearance.BorderSize = 0;
            this.btnDepositFee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDepositFee.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnDepositFee.ForeColor = System.Drawing.Color.White;
            this.btnDepositFee.Location = new System.Drawing.Point(610, 63);
            this.btnDepositFee.Name = "btnDepositFee";
            this.btnDepositFee.Size = new System.Drawing.Size(178, 43);
            this.btnDepositFee.TabIndex = 0;
            this.btnDepositFee.Text = "Deposit Fee";
            this.btnDepositFee.UseVisualStyleBackColor = false;
            this.btnDepositFee.Click += new System.EventHandler(this.btnDepositFee_Click);
            // 
            // frmFeesMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvFees);
            this.Controls.Add(this.myLabel1);
            this.Controls.Add(this.btnDepositFee);
            this.Name = "frmFeesMaster";
            this.Text = "frmFeesMaster";
            this.Load += new System.EventHandler(this.frmFeesMaster_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private myPrimaryBtn btnDepositFee;
        private myLabel myLabel1;
        private myGridView dgvFees;
    }
}