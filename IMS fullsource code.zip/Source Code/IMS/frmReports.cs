﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmReports : myForm
    {
        public frmReports()
        {
            InitializeComponent();
        }

        private void btnStudReport_Click(object sender, EventArgs e)
        {
            frmReportViewer f = new frmReportViewer("student",0);
            f.ShowDialog();
        }

        private void btnExpenseReport_Click(object sender, EventArgs e)
        {
            frmReportViewer f = new frmReportViewer("expense",0);
            f.ShowDialog();
        }

        private void myPrimaryBtn1_Click(object sender, EventArgs e)
        {
            frmReportViewer f = new frmReportViewer("fees",0);
            f.ShowDialog();
        }
    }
}
