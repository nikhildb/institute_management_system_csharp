﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace IMS
{
    public partial class frmAddStudent : myForm
    {

        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;
        string sql;
        int id;
        public frmAddStudent(int id)
        {
            InitializeComponent();
            btnDelete.Visible = false;
            this.id = id;

        }

        public void loadStudData(int id)
        {
            if (id != 0)
            {
                this.id = id;
                btnDelete.Visible = true;
                this.Text = "Edit Student";
                this.btnAdd.Text = "Update";
                groupBox1.Text = "Update Student Information";
                sql = "select name,mname, email, dob, gender, address, mobile, qualification,  " +
                    "course, batch, doj from students where id=" + id;
                try
                {
                    con = new MySqlConnection(myFun.getstring());
                    con.Open();
                    cmd = new MySqlCommand(sql, con);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    if (reader.HasRows)
                    {
                        txtName.Text = reader[0].ToString();
                        txtEmail.Text = reader[1].ToString();
                        txtEmail.Text = reader[2].ToString();
                        dob.Text = reader[3].ToString();
                        cmbGender.Text = reader[4].ToString();
                        txtAddress.Text = reader[5].ToString();
                        txtMobile.Text = reader[6].ToString();
                        txtQualification.Text = reader[7].ToString();
                        cmbCource.SelectedIndex = cmbCource.FindStringExact(reader[8].ToString());
                        cmbBatch.SelectedIndex = cmbBatch.FindStringExact(reader[9].ToString());
                        doj.Text = reader[10].ToString();

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    cmd.Dispose();
                    con.Close();

                }
            }
        }

        myFunctions myFun = new myFunctions();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("Please enter name");
                txtName.Focus();
            }
            else if (txtAddress.Text == "")
            {
                MessageBox.Show("Please enter address");
                txtAddress.Focus();
            }
            else
            {
                if (btnAdd.Text == "Save")
                {
                    
                    sql = "insert into fees(s_id,s_name,course,total_fee,received,next_payment_date) values((select max(id) from students),'" + txtName.Text + "','" + cmbCource.Text + "', (select fee from courses where c_name='"+cmbCource.Text+"' limit 1) ,0,'" + DateTime.Now.AddDays(7).ToString("yyyy-MM-dd") + "')";
                    myFun.Query(sql, "");

                    sql = "insert into students(name,mname,email,address,dob,gender," +
                        "qualification,mobile,doj,course,batch) values(" +
                        "'" + txtName.Text + "'" +
                         ",'" + myTextBox1.Text + "'" +
                        ",'" + txtEmail.Text + "'" +
                        ",'" + txtAddress.Text + "'" +
                        ",'" + dob.Value.ToString("yyyy-MM-dd") + "'" +
                         ",'" + cmbGender.Text + "'" +
                        ",'" + txtQualification.Text + "'" +
                         ",'" + txtMobile.Text + "'" +
                        ",'" + doj.Value.ToString("yyyy-MM-dd") + "'" +
                        ",'" + cmbCource.Text + "'" +
                        ",'" + cmbBatch.Text + "')";

                    
                    myFun.Query(sql, "Student added successfully !");

                    this.Close();

                }
                else if (btnAdd.Text == "Update")
                {
                    sql = "update students set name='" + txtName.Text + "'," +
                         " mname='" + myTextBox1.Text + "'," +
                        " email='" + txtEmail.Text + "'," +
                        " address='" + txtAddress.Text + "'," +
                        " dob='" + dob.Value.ToString("yyyy-MM-dd") + "'," +
                        " gender='" + cmbGender.Text + "'," +
                        " qualification='" + txtQualification.Text + "'," +
                        " mobile='" + txtMobile.Text + "', " +
                        " doj='" + doj.Value.ToString("yyyy-MM-dd") + "'," +
                        " course='" + cmbCource.Text + "'," +
                        " batch='" + cmbBatch.Text + "' where id=" + id + "";
                    myFun.Query(sql, "Student Updated Successfully !");
                }
            }
        }
        //this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
        // for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sure to delete ?", "Delete ?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                sql = "delete from students where id=" + id;
                myFun.Query(sql, "Student deleted successfully");
                this.Close();
            }
        }

        private void frmAddStudent_Load(object sender, EventArgs e)
        {
            LoadCombo();
            loadStudData(id);
        }

        private void LoadCombo()
        {
            //load cource combo
            sql = "select c_name from courses";
            try
            {
                con = new MySqlConnection(myFun.getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cmbCource.Items.Add(reader[0].ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();

            }
            //load batch combo
            sql = "select b_name from batches";
            try
            {
                con = new MySqlConnection(myFun.getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cmbBatch.Items.Add(reader[0].ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();

            }
        }
    }
}
