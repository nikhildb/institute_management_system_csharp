﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmAddBatch : myForm
    {
        string sql;
        int id;
        MySqlConnection con;
        MySqlDataReader reader;
        MySqlCommand cmd;
        myFunctions myfun = new myFunctions();

        public frmAddBatch(int id)
        {
            InitializeComponent();
            this.id = id;
            btnDelete.Visible = false;
            if (id != 0)
            {
                btnDelete.Visible = true;
                btnAddBatch.Text = "Update";
                this.Text = "Update Batch";
                sql = "select b_name,status from batches where id="+id;
                con = new MySqlConnection(myfun.getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    txtBatchName.Text = reader[0].ToString();
                    cmbStatus.Text = reader[1].ToString();
                }
            }
        }
        //this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
        // for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com


        private void btnAddBatch_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                if (btnAddBatch.Text == "Add")
                {
                    sql = "insert into batches(b_name,status) values('" + txtBatchName.Text + "','" + cmbStatus.Text + "')";
                    myfun.Query(sql, "Batch Added successfully !");
                    this.Close();
                }
                else
                {
                    sql = "update batches set b_name='" + txtBatchName.Text + "', status='"+cmbStatus.Text+"' where id="+id;
                    myfun.Query(sql, "Batch Updated Successfully");
                }
            }

        }
        public Boolean isValid()
        {
            if (string.IsNullOrWhiteSpace(txtBatchName.Text))
            {
                MessageBox.Show("Enter batch name");
                return false;
            }
            else if (cmbStatus.SelectedIndex == -1)
            {
                MessageBox.Show("Select batch status");
                cmbStatus.Focus();
            }
            return true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            sql = "delete from batches where id=" + id;
            myfun.Query(sql, "Batch deleted successfully");
            this.Close();
        }
    }
}
