﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmAddCourse : myForm
    {
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;
        string sql;
        myFunctions myFun = new myFunctions();
        int id;
        public frmAddCourse(int id)
        {
            InitializeComponent();
            btnDelete.Visible = false;
            this.id = id;
            if (id != 0)
            {
                btnSubmit.Text = "Update";
                btnDelete.Visible = true;
                this.Text = "Edit Student";
                groupBox1.Text = "Update Course Details";
                
                sql = "select id,c_name,description,duration,fee from courses where id=" + id;
                try
                {
                    con = new MySqlConnection(myFun.getstring());
                    con.Open();
                    cmd = new MySqlCommand(sql, con);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    if (reader.HasRows)
                    {
                        txtCourcename.Text = reader[1].ToString();
                        txtDescription.Text = reader[2].ToString();
                        txtDuration.Text = reader[3].ToString();
                        txtFee.Text = reader[4].ToString();
                        
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    cmd.Dispose();
                    con.Close();

                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        //this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
        // for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Text == "Submit")
            {
                sql = "insert into courses(c_name,description,duration,fee) values('"+txtCourcename.Text+ "','" + txtDescription.Text + "','" + txtDuration.Text + "'," + txtFee.Text + ")";
                myFun.Query(sql, "Course added successfully !");
            }
            else
            {
                sql = "update courses set c_name='" + txtCourcename.Text + "',description='" + txtDescription.Text + "',duration='" + txtDuration.Text + "',fee='" + txtFee.Text + "' where id="+id;
                myFun.Query(sql, "Course Updated Successfully");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            sql = "delete from courses where id="+id;
            myFun.Query(sql, "Course deleted successfully !");
        }
    }
}
