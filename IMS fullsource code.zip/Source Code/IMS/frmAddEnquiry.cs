﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmAddEnquiry : myForm
    {
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;
        string sql;
        int id;
        myFunctions myfun = new myFunctions();
        public frmAddEnquiry(int id)
        {
            InitializeComponent();
            this.id = id;
            btnDelete.Visible = false;
            if (id != 0)
            {
                btnDelete.Visible = true;
                btnSave.Text = "Update";
                this.Text = "Update Enquiry";
                sql = "select s_name,email,mobile,address,course,edate,remark,fdate from enquiry where id=" + id;
                con = new MySqlConnection(myfun.getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    txtName.Text = reader[0].ToString();
                    txtEmail.Text = reader[1].ToString();
                    txtMobile.Text = reader[2].ToString();
                    txtAddress.Text = reader[3].ToString();
                    cmbCourse.Text = reader[4].ToString();
                    dtEnquiryDate.Text = reader[5].ToString();
                    txtRemark.Text = reader[6].ToString();
                    dtFolloup.Text = reader[7].ToString();
                }
            }
        }
        //this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
        // for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                if (btnSave.Text == "Add")
                {
                    sql = "insert into enquiry(s_name,email,mobile,address,course,edate,remark,fdate) values('" + txtName.Text + "','" + txtEmail.Text + "','" + txtMobile.Text + "','" + txtAddress.Text + "','" + cmbCourse.Text + "','" + dtEnquiryDate.Value.ToString("yyyy-MM-dd") + "','" + txtRemark.Text + "','" + dtFolloup.Value.ToString("yyyy-MM-dd") + "')";
                    myfun.Query(sql, "Enquiry added successfully !");
                }
                else
                {
                    sql = "update enquiry set s_name='" + txtName.Text + "', email='" + txtEmail.Text + "',mobile='" + txtMobile.Text + "',address='" + txtAddress.Text + "',course='" + cmbCourse.Text + "',edate='" + dtEnquiryDate.Value.ToString("yyyy-MM-dd") + "',remark='" + txtRemark.Text + "',fdate='" + dtFolloup.Value.ToString("yyyy-MM-dd") + "' where id="+id;
                    myfun.Query(sql, "Enquiry updated successfully");
                }
            }
            
        }

        private bool isValid()
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("Enter Name");
                return false;
            }
            return true;
        }

        private void LoadCombo()
        {
            //load cource combo
            sql = "select c_name from courses";
            try
            {
                con = new MySqlConnection(myfun.getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cmbCourse.Items.Add(reader[0].ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();

            }
            
        }

        private void frmAddEnquiry_Load(object sender, EventArgs e)
        {
            LoadCombo();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            sql = "delete from enquiry where id=" + id;
        }

        private void btnToAdmission_Click(object sender, EventArgs e)
        {

            sql = "insert into fees(s_id,s_name,course,total_fee,received,next_payment_date) values((select max(id) from students),'" + txtName.Text + "','" + cmbCourse.Text + "', (select fee from courses where c_name='" + cmbCourse.Text + "' limit 1) ,0,'" + DateTime.Now.AddDays(7).ToString("yyyy-MM-dd") + "')";
            myfun.Query(sql, "");

            sql = "insert into students(name,email,address" +
                "mobile,doj,course) values(" +
                "'" + txtName.Text + "'" +
                ",'" + txtEmail.Text + "'" +
                ",'" + txtAddress.Text + "'" +
               
                 ",'" + txtMobile.Text + "'" +
                ",'" + DateTime.Now.ToString("yyyy-MM-dd") + "'" +
                ",'" + cmbCourse.Text + "'" +
                ")";


            myfun.Query(sql, "Student added successfully !");
            this.Close();
        }
    }
}
