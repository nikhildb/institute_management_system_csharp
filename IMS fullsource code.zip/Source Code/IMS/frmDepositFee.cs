﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmDepositFee : myForm
    {
        String sql;
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;
        myFunctions myfun = new myFunctions();
        int fid=0;
        public frmDepositFee()
        {
            InitializeComponent();
        }

        private void frmDepositFee_Load(object sender, EventArgs e)
        {
            LoadCombo();
        }
        private void LoadCombo()
        {
            //load cource combo
            sql = "select name from students";
            try
            {
                con = new MySqlConnection(myfun.getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cmbStudents.Items.Add(reader[0].ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();

            }
            
        }

        private void myPrimaryBtn1_Click(object sender, EventArgs e)
        {
            if (fid != 0) { 
                float receivedFee = float.Parse(txtRecievedFee.Text) + float.Parse(txtDepositNow.Text);
                sql = "update fees set received="+receivedFee+" where id="+fid+"";
                myfun.Query(sql, "Fees Deposited Successfully");
            }
            else
            {
                MessageBox.Show("Please select student first");
            }
        }

        private void cmbStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            sql = "select * from fees where s_name='" + cmbStudents.SelectedItem.ToString() + "'";
            con = new MySqlConnection(myfun.getstring());
            con.Open();
            cmd = new MySqlCommand(sql, con);
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                txtCourse.Text = reader["course"].ToString();
                txtTotalFees.Text = reader["total_fee"].ToString();
                txtRecievedFee.Text = reader["received"].ToString();
                fid = int.Parse(reader["id"].ToString());
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            frmReportViewer f = new frmReportViewer("invoice",fid);
            f.ShowDialog();
        }
    }
}
