﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmDashboard : Form
    {
        MySqlConnection con;
        MySqlDataAdapter adapter;
        DataTable table;
        String sql;
        myFunctions myFun = new myFunctions();
        MySqlCommand cmd;
        MySqlDataReader reader;

        public frmDashboard()
        {
            InitializeComponent();
            
        }

        private void btnTotalStudents_Click(object sender, EventArgs e)
        {
            frmStudentsMaster f = new frmStudentsMaster();
            f.ShowDialog();
        }

        private void btnTotalCources_Click(object sender, EventArgs e)
        {
            frmCoursesMaster f = new frmCoursesMaster();
            f.ShowDialog();
        }

        private void btnTotalBatches_Click(object sender, EventArgs e)
        {
            frmBatchesMaster f = new frmBatchesMaster();
            f.ShowDialog();
        }

        private void frmDashboard_Load(object sender, EventArgs e)
        {

            this.Hide();
            frmLogin f = new frmLogin();
            if (f.ShowDialog() != DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
                try
                {
                    con = new MySqlConnection(myFun.getstring());
                    con.Open();
                    sql = "select ( select count(*) from students) as cntStudents" +
                        ", (select count(*) from courses) as cntCourses" +
                        ", (select count(*) from batches) as cntBatches" +
                        ",(select count(*) from enquiry) as cntEnquiries";
                    cmd = new MySqlCommand(sql, con);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    btnTotalStuds.Text=reader["cntStudents"].ToString();
                    btnTotalCourses.Text = reader["cntCourses"].ToString();
                    btnTotalBatch.Text = reader["cntBatches"].ToString();
                    btnTotalEnq.Text = reader["cntEnquiries"].ToString();

                }
                catch(Exception ex)
                {
                    MessageBox.Show("Error :" + ex.Message);
                }
            }
            refreshGridEnquiryFolloups("select * from enquiry where fdate='" + DateTime.Now.ToString("yyyy-MM-dd") + "'");
            refreshGridFeesRemainder("select * from fees where next_payment_date='"+DateTime.Now.ToString("yyyy-MM-dd")+"'");

        }

        private void refreshGridEnquiryFolloups(string query)
        {
            try
            {
                con = new MySqlConnection(myFun.getstring());

                adapter = new MySqlDataAdapter(query, con);
                //cmdBuilder = new MySqlCommandBuilder(adapter);
                table = new DataTable();
                table.Clear();
                adapter.Fill(table);
                //if (table.Rows.Count > 0)
                dgvEnquiryFolloups.DataSource = table;
                dgvEnquiryFolloups.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvEnquiryFolloups.Columns[0].Width = 100;
                dgvEnquiryFolloups.Columns[1].Width = 250;
                dgvEnquiryFolloups.Columns[2].Width = 300;
                dgvEnquiryFolloups.Columns[3].Width = 150;
                dgvEnquiryFolloups.Columns[4].Width = 150;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void refreshGridFeesRemainder(string query)
        {
            try
            {
                con = new MySqlConnection(myFun.getstring());

                adapter = new MySqlDataAdapter(query, con);
                //cmdBuilder = new MySqlCommandBuilder(adapter);
                table = new DataTable();
                table.Clear();
                adapter.Fill(table);
                //if (table.Rows.Count > 0)
               dgvFeesRemainder.DataSource = table;
               dgvFeesRemainder.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
               dgvFeesRemainder.Columns[0].Width = 100;
               dgvFeesRemainder.Columns[1].Width = 250;
               dgvFeesRemainder.Columns[2].Width = 300;
               dgvFeesRemainder.Columns[3].Width = 150;
               dgvFeesRemainder.Columns[4].Width = 150;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void frmDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void frmDashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            
          
            
        }

        private void manageCoursesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCoursesMaster f = new frmCoursesMaster();
            f.ShowDialog();
        }

        private void manageBatchesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBatchesMaster f = new frmBatchesMaster();
            f.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            frmEnquiryMaster f = new frmEnquiryMaster();
            f.ShowDialog();

        }

        private void btnEnquiry_Click(object sender, EventArgs e)
        {
            frmEnquiryMaster f = new frmEnquiryMaster();
            f.ShowDialog();
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            frmStudentsMaster f = new frmStudentsMaster();
            f.ShowDialog();
        }

        private void toolStripSMSButton_Click(object sender, EventArgs e)
        {
            frmSMS f = new frmSMS();
            f.ShowDialog();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            frmFeesMaster f = new frmFeesMaster();
            f.ShowDialog();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            frmReports f = new frmReports();
            f.ShowDialog();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            frmExpensesMaster f = new frmExpensesMaster();
            f.ShowDialog();

        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AboutBox1 f = new AboutBox1();
            f.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://nikhilbhalerao.com/");

        }
    }
}
