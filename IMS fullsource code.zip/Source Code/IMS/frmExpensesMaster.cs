﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class frmExpensesMaster : myForm
    {
        string sql = "select * from expenses";
        myFunctions myFun = new myFunctions();
        MySqlConnection con;
        MySqlDataAdapter adapter;
        DataTable table;
        public frmExpensesMaster()
        {
            InitializeComponent();
        }
        private void refreshGrid(string query)
        {
            try
            {
                con = new MySqlConnection(myFun.getstring());

                adapter = new MySqlDataAdapter(query, con);
                //cmdBuilder = new MySqlCommandBuilder(adapter);
                table = new DataTable();
                table.Clear();
                adapter.Fill(table);
                //if (table.Rows.Count > 0)
                dgvExpenses.DataSource = table;
                dgvExpenses.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvExpenses.Columns[0].Width = 100;
                dgvExpenses.Columns[1].Width = 250;
                dgvExpenses.Columns[2].Width = 300;
                dgvExpenses.Columns[3].Width = 150;
                dgvExpenses.Columns[4].Width = 150;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddExpense_Click(object sender, EventArgs e)
        {
            frmAddExpense f = new frmAddExpense();
            f.ShowDialog();
            refreshGrid("select * from expenses");
        }

        private void frmExpensesMaster_Load(object sender, EventArgs e)
        {
            refreshGrid(sql);
        }
        private void editexpense()
        {
            int id = int.Parse(dgvExpenses.SelectedCells[0].Value.ToString());
            frmAddExpense f = new frmAddExpense(id);
            f.ShowDialog();
            refreshGrid(sql);
        }
        private void dgvExpenses_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            editexpense();
        }

        private void dgvExpenses_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                editexpense();
            }
        }
    }
}
