﻿namespace IMS
{
    partial class frmBatchesMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgBatches = new IMS.myGridView();
            this.btnNewBatch = new IMS.myPrimaryBtn();
            this.myLabel1 = new IMS.myLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgBatches)).BeginInit();
            this.SuspendLayout();
            // 
            // dgBatches
            // 
            this.dgBatches.AllowUserToAddRows = false;
            this.dgBatches.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgBatches.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(2);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgBatches.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgBatches.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBatches.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgBatches.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgBatches.EnableHeadersVisualStyles = false;
            this.dgBatches.GridColor = System.Drawing.Color.White;
            this.dgBatches.Location = new System.Drawing.Point(0, 76);
            this.dgBatches.MultiSelect = false;
            this.dgBatches.Name = "dgBatches";
            this.dgBatches.ReadOnly = true;
            this.dgBatches.RowHeadersVisible = false;
            this.dgBatches.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgBatches.Size = new System.Drawing.Size(592, 266);
            this.dgBatches.TabIndex = 0;
            this.dgBatches.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBatches_CellDoubleClick);
            this.dgBatches.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgBatches_KeyDown);
            // 
            // btnNewBatch
            // 
            this.btnNewBatch.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnNewBatch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNewBatch.FlatAppearance.BorderSize = 0;
            this.btnNewBatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewBatch.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btnNewBatch.ForeColor = System.Drawing.Color.White;
            this.btnNewBatch.Location = new System.Drawing.Point(434, 19);
            this.btnNewBatch.Name = "btnNewBatch";
            this.btnNewBatch.Size = new System.Drawing.Size(144, 41);
            this.btnNewBatch.TabIndex = 1;
            this.btnNewBatch.Text = "New Batch";
            this.btnNewBatch.UseVisualStyleBackColor = false;
            this.btnNewBatch.Click += new System.EventHandler(this.btnNewBatch_Click);
            // 
            // myLabel1
            // 
            this.myLabel1.AutoSize = true;
            this.myLabel1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myLabel1.ForeColor = System.Drawing.Color.White;
            this.myLabel1.Location = new System.Drawing.Point(158, 28);
            this.myLabel1.Name = "myLabel1";
            this.myLabel1.Size = new System.Drawing.Size(186, 32);
            this.myLabel1.TabIndex = 2;
            this.myLabel1.Text = "Batch Master";
            // 
            // frmBatchesMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(590, 342);
            this.Controls.Add(this.myLabel1);
            this.Controls.Add(this.btnNewBatch);
            this.Controls.Add(this.dgBatches);
            this.Name = "frmBatchesMaster";
            this.Text = "frmBatchesMaster";
            this.Load += new System.EventHandler(this.frmBatchesMaster_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgBatches)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private myGridView dgBatches;
        private myPrimaryBtn btnNewBatch;
        private myLabel myLabel1;
    }
}