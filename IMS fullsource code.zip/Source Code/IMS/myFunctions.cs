﻿//this code is developed by Nikhil B. he is fulltime freelancer working from last 7 years 
// for any development work related to PHP,CI OR Laravel at affordable rates contact +919423979339  OR visit website : nikhilbhalerao.com
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    class myFunctions
    {
        string DatabaseName = "imsdb";
        string server = "localhost";
        string userName = "root";
        string password = "";
        MySqlConnection con;
        MySqlCommand cmd;

        public string getstring()
        {
            return String.Format("server={0}; user id={1}; password={2}; database={3}; Convert Zero Datetime=True; pooling=false", server, userName, password, DatabaseName);
        }

        public void Query(string sql, string message)
        {
            try
            {
                con = new MySqlConnection(getstring());
                con.Open();
                cmd = new MySqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                if (message == "")
                {

                }
                else
                {
                    MessageBox.Show(message);
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
